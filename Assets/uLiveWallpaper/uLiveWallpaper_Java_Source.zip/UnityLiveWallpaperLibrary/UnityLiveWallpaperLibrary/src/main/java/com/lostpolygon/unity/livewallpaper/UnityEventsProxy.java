/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.livewallpaper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * Notifies about Live Wallpaper events.
 * Compares the event data with previous event data and only sends the event if data has changed.
 *
 * Note: Currently, the only listener is on the Unity C# side.
 */
public final class UnityEventsProxy implements ILiveWallpaperEventsListener {
    /**
     * Listeners to the {@code WallpaperService.Engine} callbacks.
     */
    private final List<ILiveWallpaperEventsListener> mLiveWallpaperEventsListeners =  new ArrayList<>();

    private final VisibilityChangedEventDispatcher mVisibilityChangedEventDispatcher = new VisibilityChangedEventDispatcher();
    private final OffsetsChangedEventDispatcher mOffsetsChangedEventDispatcher = new OffsetsChangedEventDispatcher();
    private final IsPreviewChangedEventDispatcher mIsPreviewChangedEventDispatcher = new IsPreviewChangedEventDispatcher();
    private final DesiredSizeChangedEventDispatcher mDesiredSizeChangedEventDispatcher = new DesiredSizeChangedEventDispatcher();
    private final PreferenceChangedEventDispatcher mPreferenceChangedEventDispatcher = new PreferenceChangedEventDispatcher();
    private final PreferenceActivityTriggeredEventDispatcher mPreferenceActivityTriggeredEventDispatcher = new PreferenceActivityTriggeredEventDispatcher();
    private final MultiTapDetectedEventDispatcher mMultiTapDetectedEventDispatcher = new MultiTapDetectedEventDispatcher();
    private final CustomEventReceivedEventDispatcher mCustomEventReceivedEventDispatcher = new CustomEventReceivedEventDispatcher();

    private final EventDispatcher[] mEventDispatchers = new EventDispatcher[] {
        mVisibilityChangedEventDispatcher,
        mOffsetsChangedEventDispatcher,
        mIsPreviewChangedEventDispatcher,
        mDesiredSizeChangedEventDispatcher,
        mPreferenceChangedEventDispatcher,
        mPreferenceActivityTriggeredEventDispatcher,
        mMultiTapDetectedEventDispatcher,
        mCustomEventReceivedEventDispatcher,
    };

    /**
     * Registers an event listener.
     * Note: Called from C# code.
     * @param listener
     */
    public void registerLiveWallpaperEventsListener(ILiveWallpaperEventsListener listener) {
        if (listener == null)
            throw new IllegalArgumentException("listener == null");

        if (mLiveWallpaperEventsListeners.contains(listener))
            return;

        mLiveWallpaperEventsListeners.add(listener);
    }

    /**
     * Unregisters an event listener.
     * Note: Called from C# code.
     * @param listener
     */
    public void unregisterLiveWallpaperEventsListener(ILiveWallpaperEventsListener listener) {
        if (listener == null)
            throw new IllegalArgumentException("listener == null");

        mLiveWallpaperEventsListeners.remove(listener);
    }

    /**
     * Notifies listeners about whether the wallpaper has become visible or not visible.
     * @param isVisible
     */
    public void visibilityChanged(boolean isVisible) {
        mVisibilityChangedEventDispatcher.Enqueue(new VisibilityChangedEvent(isVisible));
    }

    /**
     * Notifies listeners about whether the wallpaper has entered or exited the preview mode.
     * @param isPreview
     */
    public void isPreviewChanged(boolean isPreview) {
        mIsPreviewChangedEventDispatcher.Record(isPreview);
    }

    /**
     * Notifies listeners about wallpaper desired size change.
     * @param desiredWidth
     * @param desiredHeight
     */
    public void desiredSizeChanged(int desiredWidth, int desiredHeight) {
        mDesiredSizeChangedEventDispatcher.Record(desiredWidth, desiredHeight);
    }

    /**
     * Notifies listeners about wallpaper offsets change.
     * @param xOffset
     * @param yOffset
     * @param xOffsetStep
     * @param yOffsetStep
     * @param xPixelOffset
     * @param yPixelOffset
     */
    public void offsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
        mOffsetsChangedEventDispatcher.Record(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset);
    }

    /**
     * Called to inform that live wallpaper preferences Activity has started.
     */
    public void preferencesActivityTriggered() {
        mPreferenceActivityTriggeredEventDispatcher.Enqueue(new PreferenceActivityTriggeredEvent());
    }

    /**
     * Notifies listeners about preference value change.
     * @param key SharedPreferences preference key that has changed.
     */

    public void preferenceChanged(String key) {
        mPreferenceChangedEventDispatcher.Enqueue(new PreferenceChangedEvent(key));
    }

    /**
     * Called to inform about a custom event.
     * @param eventName Name of the event.
     * @param eventData Event data.
     */
    public void customEventReceived(String eventName, String eventData) {
        mCustomEventReceivedEventDispatcher.Enqueue(new CustomEventReceivedEvent(eventName, eventData));
    }

    /**
     * Called to inform that user has tapped the screen multiple times.
     */
    public void multiTapDetected(float finalTapPositionX, float finalTapPositionY) {
        mMultiTapDetectedEventDispatcher.Record(finalTapPositionX, finalTapPositionY);
    }

    /**
     * Sends stored events to the listeners.
     * Note: Called from C# code.
     */
    public void dispatchEvents() {
        for (EventDispatcher eventDispatcher : mEventDispatchers) {
            eventDispatcher.Dispatch();
        }
    }

    /* Base event dispatcher classes */

    private abstract class EventBase<T> {
        public abstract boolean isEqual(T other);
    }

    private abstract class EventDispatcher {
        public abstract void Dispatch();
    }

    private abstract class QueuedEventDispatcher<T extends EventBase<T>> extends EventDispatcher {
        private final LinkedBlockingDeque<T> _queue = new LinkedBlockingDeque<>();

        @Override
        public void Dispatch() {
            synchronized (_queue) {
                while (_queue.size() > 0) {
                    T event = _queue.remove();
                    for (ILiveWallpaperEventsListener listener : mLiveWallpaperEventsListeners) {
                        DispatchEvent(listener, event);
                    }
                }
            }
        }

        public boolean Enqueue(T event) {
            synchronized (_queue) {
                if (_queue.size() == 0 || !_queue.peekLast().isEqual(event)) {
                    _queue.offer(event);
                    return true;
                }

                return false;
            }
        }

        protected abstract void DispatchEvent(ILiveWallpaperEventsListener listener, T event);
    }

    private abstract class ImmediateEventDispatcher extends EventDispatcher {
        protected boolean mIsDispatched;
        protected boolean mHasValue;

        @Override
        public void Dispatch() {
            if (!mHasValue || mIsDispatched)
                return;

            synchronized (this) {
                for (ILiveWallpaperEventsListener listener : mLiveWallpaperEventsListeners) {
                    DispatchEvent(listener);
                }

                mIsDispatched = true;
                mHasValue = false;
            }
        }

        protected abstract void DispatchEvent(ILiveWallpaperEventsListener listener);
    }

    /* VisibilityChanged */

    private class VisibilityChangedEvent extends EventBase<VisibilityChangedEvent> {
        public final boolean IsVisible;

        public VisibilityChangedEvent(boolean isVisible) {
            IsVisible = isVisible;
        }

        @Override
        public boolean isEqual(VisibilityChangedEvent other) {
            return IsVisible == other.IsVisible;
        }
    }

    private class VisibilityChangedEventDispatcher extends QueuedEventDispatcher<VisibilityChangedEvent> {
        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener, VisibilityChangedEvent event) {
            listener.visibilityChanged(event.IsVisible);
        }
    }

    /* OffsetsChanged */

    private class OffsetsChangedEventDispatcher extends ImmediateEventDispatcher {
        private float mXOffset;
        private float mYOffset;
        private float mXOffsetStep;
        private float mYOffsetStep;
        private int mXPixelOffset;
        private int mYPixelOffset;

        public boolean Record(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
            synchronized (this) {
                boolean result = !mHasValue;
                if (mXOffset != xOffset ||
                    mYOffset != yOffset ||
                    mXOffsetStep != xOffsetStep ||
                    mYOffsetStep != yOffsetStep ||
                    mXPixelOffset != xPixelOffset ||
                    mYPixelOffset != yPixelOffset
                    ) {
                    result = true;
                }

                if (result) {
                    mHasValue = true;
                    mIsDispatched = false;
                    mXOffset = xOffset;
                    mYOffset = yOffset;
                    mXOffsetStep = xOffsetStep;
                    mYOffsetStep = yOffsetStep;
                    mXPixelOffset = xPixelOffset;
                    mYPixelOffset = yPixelOffset;
                }

                return result;
            }
        }

        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener) {
            listener.offsetsChanged(mXOffset, mYOffset, mXOffsetStep, mYOffsetStep, mXPixelOffset, mYPixelOffset);
        }
    }

    /* IsPreviewChanged */

    private class IsPreviewChangedEventDispatcher extends ImmediateEventDispatcher {
        private boolean mIsPreview;

        public boolean Record(boolean isPreview) {
            synchronized (this) {
                boolean result = !mHasValue;
                if (mIsPreview != isPreview) {
                    result = true;
                }

                if (result) {
                    mHasValue = true;
                    mIsDispatched = false;
                    mIsPreview = isPreview;
                }

                return result;
            }
        }

        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener) {
            listener.isPreviewChanged(mIsPreview);
        }
    }

    /* DesiredSizeChanged */

    private class DesiredSizeChangedEventDispatcher extends ImmediateEventDispatcher {
        private int mDesiredWidth;
        private int mDesiredHeight;

        public boolean Record(int desiredWidth, int desiredHeight) {
            synchronized (this) {
                boolean result = !mHasValue;
                if (mDesiredWidth != desiredWidth ||
                    mDesiredHeight != desiredHeight
                    ) {
                    result = true;
                }

                if (result) {
                    mHasValue = true;
                    mIsDispatched = false;
                    mDesiredWidth = desiredWidth;
                    mDesiredHeight = desiredHeight;
                }

                return result;
            }
        }

        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener) {
            listener.desiredSizeChanged(mDesiredWidth, mDesiredHeight);
        }
    }

    /* PreferenceChanged */

    private class PreferenceChangedEvent extends EventBase<PreferenceChangedEvent> {
        public final String PreferenceKey;

        public PreferenceChangedEvent(String preferenceKey) {
            PreferenceKey = preferenceKey;
        }

        @Override
        public boolean isEqual(PreferenceChangedEvent other) {
            return PreferenceKey.equals(other.PreferenceKey);
        }
    }

    private class PreferenceChangedEventDispatcher extends QueuedEventDispatcher<PreferenceChangedEvent> {
        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener, PreferenceChangedEvent event) {
            listener.preferenceChanged(event.PreferenceKey);
        }
    }

    /* PreferenceActivityTriggered */

    private class PreferenceActivityTriggeredEvent extends EventBase<PreferenceActivityTriggeredEvent> {
        @Override
        public boolean isEqual(PreferenceActivityTriggeredEvent other) {
            // Each event must be added into the queue
            return false;
        }
    }

    private class PreferenceActivityTriggeredEventDispatcher extends QueuedEventDispatcher<PreferenceActivityTriggeredEvent> {
        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener, PreferenceActivityTriggeredEvent event) {
            listener.preferencesActivityTriggered();
        }
    }

    /* MultiTapDetected */

    private class MultiTapDetectedEventDispatcher extends ImmediateEventDispatcher {
        private float mFinalTapPositionX;
        private float mFinalTapPositionY;

        public boolean Record(float finalTapPositionX, float finalTapPositionY) {
            synchronized (this) {
                boolean result = !mHasValue;
                if (mFinalTapPositionX != finalTapPositionX ||
                    mFinalTapPositionY != finalTapPositionY
                    ) {
                    result = true;
                }

                if (result) {
                    mHasValue = true;
                    mIsDispatched = false;
                    mFinalTapPositionX = finalTapPositionX;
                    mFinalTapPositionY = finalTapPositionY;
                }

                return result;
            }
        }

        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener) {
            listener.multiTapDetected(mFinalTapPositionX, mFinalTapPositionY);
        }
    }
    
    /* CustomEventReceived */

    private class CustomEventReceivedEvent extends EventBase<CustomEventReceivedEvent> {
        public final String EventName;
        public final String EventData;

        public CustomEventReceivedEvent(String eventName, String eventData) {
            EventName = eventName;
            EventData = eventData;
        }

        @Override
        public boolean isEqual(CustomEventReceivedEvent other) {
            // Each event must is added into queue
            return false;
        }
    }

    private class CustomEventReceivedEventDispatcher extends QueuedEventDispatcher<CustomEventReceivedEvent> {
        @Override
        protected void DispatchEvent(ILiveWallpaperEventsListener listener, CustomEventReceivedEvent event) {
            listener.customEventReceived(event.EventName, event.EventData);
        }
    }
}
