package com.lostpolygon.unity.livewallpaper.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.lostpolygon.unity.androidintegration.MultiTapDetector;
import com.lostpolygon.unity.androidintegration.UnityPlayerHolder;
import com.lostpolygon.unity.androidintegration.UnityPlayerInstanceManager;
import com.lostpolygon.unity.androidintegration.UnityPlayerWrapper;
import com.lostpolygon.unity.androidintegration.UnityPlayerWrapperInstantiator;
import com.lostpolygon.unity.androidintegration.UnityVersionInfo;
import com.lostpolygon.unity.androidintegration.DebugLog;
import com.lostpolygon.unity.livewallpaper.LiveWallpaperUnityFacade;
import com.lostpolygon.unity.livewallpaper.UnityEventsProxy;

/**
 * A Unity player Activity that shares the Unity player instance with the live wallpaper service.
 */
public abstract class LiveWallpaperCompatibleUnityPlayerActivity extends Activity {
    @SuppressLint("StaticFieldLeak")
    private static LiveWallpaperCompatibleUnityPlayerActivity sCurrentActivity;

    /**
     * Name of the event sent when Unity player is resumed by this Activity.
     */
    public static final String UNITY_EVENT_PLAYER_RESUMED = "UnityPlayerResumed";

    /**
     * Name of the event sent when Unity player is paused by this Activity.
     */
    public static final String UNITY_EVENT_PLAYER_PAUSED = "UnityPlayerPaused";

    /**
     * Name of the event sent when Activity.onResume() is called.
     */
    public static final String UNITY_EVENT_ACTIVITY_ONSTART = "UnityActivityOnStart";

    /**
     * Name of the event sent when Activity.onResume() is called.
     */
    public static final String UNITY_EVENT_ACTIVITY_ONRESUME = "UnityActivityOnResume";

    /**
     * Name of the event sent when Activity.onPause() is called.
     */
    public static final String UNITY_EVENT_ACTIVITY_ONPAUSE = "UnityActivityOnPause";

    /**
     * Name of the event sent when Activity.onStop() is called.
     */
    public static final String UNITY_EVENT_ACTIVITY_ONSTOP = "UnityActivityOnStop";

    /**
     * {@code SurfaceView} for Unity player rendering.
     */
    protected SurfaceView mSurfaceView;

    /**
     * {@code SurfaceHolder} that contains the {@code Surface} used for Unity player rendering.
     */
    protected SurfaceHolder mSurfaceHolder;

    protected UnityPlayerHolder mUnityPlayerHolder;

    private final UnityEventsProxy mUnityEventsProxy = LiveWallpaperUnityFacade.getEventsProxy();
    private final MultiTapDetector.IMultiTapDetectedListener mMultiTapDetectedListener = new MultiTapDetector.IMultiTapDetectedListener() {
        @Override
        public void onMultiTapDetected(float finalTapPositionX, float finalTapPositionY) {
            mUnityEventsProxy.multiTapDetected(finalTapPositionX, finalTapPositionY);
        }
    };
    private final UnityPlayerSurfaceHolderCallbackReceiver mSurfaceHolderCallbackReceiver = new UnityPlayerSurfaceHolderCallbackReceiver();

    /**
     * Whether {@code mSurfaceHolder} currently holds a valid {@code Surface}.
     */
    private boolean mIsSurfaceCreated;

    /**
     * Whether the Activity is currently visible.
     */
    private boolean mIsVisible;

    private UnityPlayerWrapper mUnityPlayerWrapper;
    private LiveWallpaperUnityFacade mLiveWallpaperUnityFacade;
    private UnityPlayerInstanceManager mUnityPlayerInstanceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Update Unity version info
        UnityVersionInfo.updateUnityVersionIfNeeded(this);
        DebugLog.logStartupMessage();

        // Create the Layout for this Activity
        mSurfaceView = onCreateLayout();
        if (mSurfaceView == null)
            throw new RuntimeException("mSurfaceView == null");

        // This makes xperia play happy
        getWindow().setFormat(PixelFormat.RGBX_8888);

        // Get the surface holder. At this point, it should point at null Surface.
        mSurfaceHolder = mSurfaceView.getHolder();

        // Install a SurfaceHolder.Callback so we get notified when the
        // underlying surface is created and destroyed.
        mSurfaceHolder.addCallback(mSurfaceHolderCallbackReceiver);

        // Instantiate the Unity player
        final UnityPlayerWrapperInstantiator unityPlayerWrapperInstantiator = new UnityPlayerWrapperInstantiator(this) {
            @Override
            public boolean isVisible() {
                return mIsVisible;
            }

            @Override
            public SurfaceHolder getSurfaceHolder() {
                return mSurfaceHolder;
            }

            @Override
            public void onAlreadyInstantiated() {
                mUnityPlayerInstanceManager = UnityPlayerInstanceManager.getInstance();
                mLiveWallpaperUnityFacade = LiveWallpaperUnityFacade.getInstance();
            }

            @Override
            public void onUnityPlayerInstanceCreated() {
                onAlreadyInstantiated();
            }

            @Override
            public void onSetUnityPlayerWrapper(UnityPlayerWrapper unityPlayerWrapper) {
                mUnityPlayerWrapper = unityPlayerWrapper;
            }

            @Override
            public void onSetUnityPlayerHolder(UnityPlayerHolder unityPlayerHolder) {
                mUnityPlayerHolder = unityPlayerHolder;
            }
        };

        unityPlayerWrapperInstantiator.instantiate();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mUnityPlayerWrapper != null) {
            mUnityEventsProxy.customEventReceived(UNITY_EVENT_ACTIVITY_ONSTART, "");
        }

        if (getUnityPlayerResumeEvent() != UnityPlayerResumeEventType.OnActivityStart)
            return;

        DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: onStart");
        mIsVisible = true;

        if (mUnityPlayerWrapper == null)
            return;

        resumeUnityPlayer();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mUnityPlayerWrapper != null) {
            mUnityEventsProxy.customEventReceived(UNITY_EVENT_ACTIVITY_ONRESUME, "");
        }

        if (getUnityPlayerResumeEvent() != UnityPlayerResumeEventType.OnActivityResume)
            return;

        DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: onResume");
        mIsVisible = true;

        if (mUnityPlayerWrapper == null)
            return;

        resumeUnityPlayer();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mUnityPlayerWrapper != null) {
            mUnityEventsProxy.customEventReceived(UNITY_EVENT_ACTIVITY_ONPAUSE, "");
        }

        if (getUnityPlayerPauseEvent() != UnityPlayerPauseEventType.OnActivityPause)
            return;

        DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: onPause");
        mIsVisible = false;

        if (mUnityPlayerWrapper == null)
            return;

        pauseUnityPlayer();
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mUnityPlayerWrapper != null) {
            mUnityEventsProxy.customEventReceived(UNITY_EVENT_ACTIVITY_ONSTOP, "");
        }

        if (getUnityPlayerPauseEvent() != UnityPlayerPauseEventType.OnActivityStop)
            return;

        DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: onStop");
        mIsVisible = false;

        if (mUnityPlayerWrapper == null)
            return;

        pauseUnityPlayer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: onDestroy");

        sCurrentActivity = null;
        updateUnityPlayerActivityContext();

        // Only unregister on when Activity is destroyed, as we want the Unity process to killed
        // when Activity is destroyed, not just hidden. This allows to resume when user puts the Activity to background.
        if (mUnityPlayerHolder != null) {
            mUnityPlayerHolder.unregister();
        }

        if (UnityPlayerWrapper.getUnityPlayerCurrentActivity() == this) {
            UnityPlayerWrapper.setUnityPlayerCurrentActivity(null);
        }

        // {@code UnityPlayer} is destroyed together with {@code LiveWallpaperCompatibleUnityPlayerActivity}.
        // The side effect is that not only {@code LiveWallpaperCompatibleUnityPlayerActivity} is destroyed,
        // but the whole application process dies.
        if (UnityPlayerInstanceManager.getInstance().getUnityPlayerWrapperInstance() != null &&
            UnityPlayerInstanceManager.getInstance().getUnityPlayerPauseResumeManager().getUnityPlayerHoldersCount() == 0
            ) {
            UnityPlayerInstanceManager.getInstance().getUnityPlayerWrapperInstance().quitPlayer();
        }
    }

    @Override
    public boolean isFinishing() {
        if (!super.isFinishing())
            return false;

        // One of the ugliest hacks ever devised by mankind.
        //
        // HACK: Unity is doing something weird, pausing the UnityMain thread if isFinishing() ever returns true.
        // This code avoids this by always returning false when called from any Unity classes.
        // Unfortunately, there doesn't seems to be a way to avoid this in any "correct" way.
        StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
        for (int i = 0, n = stacktrace.length; i < n; i++) {
            StackTraceElement element = stacktrace[i];
            if (element.getClassName().startsWith("com.unity3d.player"))
                return false;
        }

        return true;
    }

    // This ensures the layout will be correct.
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        if (mUnityPlayerWrapper == null)
            return;

        mUnityPlayerWrapper.injectConfigurationChange(newConfig);
    }

    // For some reason the multiple keyevent type is not supported by the ndk.
    // Force event injection by overriding dispatchKeyEvent().
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (mUnityPlayerWrapper == null && event.getAction() == KeyEvent.ACTION_MULTIPLE)
            return mUnityPlayerWrapper.injectInputEvent(event);

        return super.dispatchKeyEvent(event);
    }

    // Pass any events not handled by (unfocused) views straight to UnityPlayer
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        super.onKeyUp(keyCode, event);

        if (mUnityPlayerWrapper == null)
            return false;

        return mUnityPlayerWrapper.injectInputEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        super.onKeyDown(keyCode, event);

        if (mUnityPlayerWrapper == null)
            return false;

        return mUnityPlayerWrapper.injectInputEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);

        if (mUnityPlayerWrapper == null)
            return false;

        if (mLiveWallpaperUnityFacade != null) {
            mLiveWallpaperUnityFacade.getMultiTapDetector().onTouchEvent(event);
        }

        return mUnityPlayerWrapper.injectInputEvent(event);
    }

    /*API12*/
    public boolean onGenericMotionEvent(MotionEvent event)  {
        super.onGenericMotionEvent(event);

        if (mUnityPlayerWrapper == null)
            return false;

        return mUnityPlayerWrapper.injectInputEvent(event);
    }

    /**
     * Determines the event at which the Unity player must be resumed.
     */
    protected UnityPlayerResumeEventType getUnityPlayerResumeEvent() {
        return UnityPlayerResumeEventType.OnActivityStart;
    }

    /**
     * Determines the event at which the Unity player must be paused.
     */
    protected UnityPlayerPauseEventType getUnityPlayerPauseEvent() {
        return UnityPlayerPauseEventType.OnActivityStop;
    }

    /**
     * Override this method to implement custom layout.
     * @return The {@code SurfaceView} that will contain the Unity player.
     */
    protected SurfaceView onCreateLayout() {
        // Create LinearLayout
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams linearLayoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        linearLayout.setLayoutParams(linearLayoutParams);

        // Create SurfaceView for Unity
        final SurfaceView unitySurfaceView = new SurfaceView(this);
        final ViewGroup.LayoutParams surfaceViewLayoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        unitySurfaceView.setLayoutParams(surfaceViewLayoutParams);

        // Add SurfaceView as child of LinearLayout
        linearLayout.addView(unitySurfaceView);

        // Set LinearLayout as root element of the screen
        setContentView(linearLayout);
        return unitySurfaceView;
    }

    protected boolean resumeUnityPlayer() {
        if (!mIsVisible || !mIsSurfaceCreated)
            return false;

        mUnityPlayerInstanceManager.setActiveUnityPlayerHolder(mUnityPlayerHolder);
        boolean isAppliedChanges = mUnityPlayerHolder.onVisibilityChanged(true, mSurfaceHolder);

        if (isAppliedChanges) {
            // Set Unity player Context to this Activity to allow soft input
            sCurrentActivity = this;
            updateUnityPlayerActivityContext();

            int width = mSurfaceHolder.getSurfaceFrame().width();
            int height = mSurfaceHolder.getSurfaceFrame().height();

            // Setup MultiTapDetector
            if (mLiveWallpaperUnityFacade != null) {
                mLiveWallpaperUnityFacade.getMultiTapDetector().registerMultiTapDetectedListener(mMultiTapDetectedListener);
                mLiveWallpaperUnityFacade.getMultiTapDetector().setScreenSize(new Point(width, height));
            }

            // Send events to C#
            mUnityEventsProxy.desiredSizeChanged(width, height);
            mUnityEventsProxy.visibilityChanged(true);
            mUnityEventsProxy.isPreviewChanged(false);
            mUnityEventsProxy.customEventReceived(UNITY_EVENT_PLAYER_RESUMED, "");
        }

        return isAppliedChanges;
    }

    protected boolean pauseUnityPlayer() {
        int visibleUnityPlayerHoldersCount = UnityPlayerInstanceManager.getInstance().getUnityPlayerPauseResumeManager().getVisibleUnityPlayerHoldersCount();

        boolean isAppliedChanges = visibleUnityPlayerHoldersCount > 0 && mUnityPlayerHolder.isVisible();
        if (mUnityPlayerInstanceManager.getActiveUnityPlayerHolder() == mUnityPlayerHolder) {
            // Send events to C#
            if (isAppliedChanges) {
                if (sCurrentActivity == this) {
                    sCurrentActivity = null;
                }
                // Unregister MultiTapDetector
                if (mLiveWallpaperUnityFacade != null) {
                    mLiveWallpaperUnityFacade.getMultiTapDetector().unregisterMultiTapDetectedListener(mMultiTapDetectedListener);
                }

                // Send events to C#
                mUnityEventsProxy.visibilityChanged(false);
                mUnityEventsProxy.customEventReceived(UNITY_EVENT_PLAYER_PAUSED, "");
            }

            // Handle pause
            mUnityPlayerHolder.onVisibilityChanged(false, null);
            mUnityPlayerInstanceManager.setActiveUnityPlayerHolder(null);
        }

        return isAppliedChanges;
    }

    /**
     * Updates the {@code Context} used by Unity player internally.
     * Note: Called from C# code.
     */
    public static void updateUnityPlayerActivityContext() {
        UnityPlayerInstanceManager.getInstance().getUnityPlayerWrapperInstance().setContext(sCurrentActivity);
        UnityPlayerWrapper.setUnityPlayerCurrentActivity(sCurrentActivity);
    }

    protected enum UnityPlayerResumeEventType {
        OnActivityStart,
        OnActivityResume
    }

    protected enum UnityPlayerPauseEventType {
        OnActivityStop,
        OnActivityPause
    }

    private class UnityPlayerSurfaceHolderCallbackReceiver implements SurfaceHolder.Callback {
        @Override
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: surfaceCreated");

            mSurfaceHolder = surfaceHolder;
            mIsSurfaceCreated = true;

            if (mUnityPlayerWrapper == null)
                return;

            resumeUnityPlayer();
        }

        @Override
        public void surfaceChanged(SurfaceHolder surfaceHolder, int format, int width, int height) {
            DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: surfaceChanged");

            mSurfaceHolder = surfaceHolder;
            if (mUnityPlayerWrapper == null)
                return;

            // Update Unity player surface
            if (mUnityPlayerInstanceManager.getActiveUnityPlayerHolder() == mUnityPlayerHolder) {
                mUnityPlayerWrapper.setPlayerSurface(mSurfaceHolder);
            }
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            DebugLog.v("LiveWallpaperCompatibleUnityPlayerActivity: surfaceDestroyed");

            mIsSurfaceCreated = false;
            if (mUnityPlayerWrapper == null)
                return;

            pauseUnityPlayer();
            if (surfaceHolder != null) {
                mUnityPlayerWrapper.handleSurfaceDestroyed(surfaceHolder);
            }
        }
    }
}
