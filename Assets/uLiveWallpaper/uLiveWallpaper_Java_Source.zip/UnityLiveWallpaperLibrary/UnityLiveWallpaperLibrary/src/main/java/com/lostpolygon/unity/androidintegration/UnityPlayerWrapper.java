/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.view.InputEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.unity3d.player.UnityPlayer;

/**
 * Provides safe and convenient access to {@code UnityPlayer}.
 */
public final class UnityPlayerWrapper {
    private final Context mApplicationContext;
    private final UnityPlayer mUnityPlayer;
    private final VSyncManagerWrapper mVSyncManagerWrapper;
    private final UnityPlayerPackageClasses mUnityPlayerPackageClasses;
    private Field mUnityPlayerContextWrapperField;

    /**
     * Current {@code SurfaceHolder} used by {@code UnityPlayer}.
     */
    private SurfaceHolder mSurfaceHolder;

    /**
     * @param contextWrapper {@code ContextWrapper} passed to {@code UnityPlayer} constructor.
     */
    public UnityPlayerWrapper(ContextWrapper contextWrapper) {
        UnityVersionInfo.updateUnityVersionIfNeeded(contextWrapper);
        mApplicationContext = contextWrapper.getApplicationContext();
        mUnityPlayerPackageClasses = new UnityPlayerPackageClasses(mApplicationContext);

        // This has to be done before Unity player is created, since it uses some values in constructor.
        if (UnityVersionInfo.getInstance().hasApi23PermissionRequestSupport()) {
            try {
                final PackageManager packageManager = contextWrapper.getPackageManager();
                final ApplicationInfo applicationInfo = packageManager.getApplicationInfo(contextWrapper.getPackageName(), PackageManager.GET_META_DATA);
                if (applicationInfo.targetSdkVersion >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    DebugLog.v("Disabling Unity API 23 permission request dialog");
                    disableConflictingApi23Support();
                }
            } catch (Throwable e) {
                DebugLog.e(
                    "Unable to disable conflicting built-in Unity player API 23 permission request dialog. " +
                    "This may result in wallpaper not starting when some permissions are not granted. Please report this!\n"
                );
                e.printStackTrace();
            }
        }

        mUnityPlayer = new UnityPlayer(contextWrapper);

        // Disable VSync listening from the start
        if (!UnityVersionInfo.getInstance().isUnity540orNewer()) {
            mVSyncManagerWrapper = new VSyncManagerWrapper();
            mVSyncManagerWrapper.unregisterVSyncListener();
        } else {
            mVSyncManagerWrapper = null;
        }

        setupUnityPlayerInnerState(contextWrapper);
    }

    /**
     * Returns the Application {@code Context}.
     *
     * @return Application {@code Context}.
     */
    public Context getApplicationContext() {
        return mApplicationContext;
    }

    /**
     * Resumes the {@code UnityPlayer}
     */
    public void resumePlayer() {
        DebugLog.d("UnityPlayerWrapper: Resuming");
        mUnityPlayer.resume();
        mUnityPlayer.windowFocusChanged(true);
    }

    /**
     * Pauses the {@code UnityPlayer}.
     */
    public void pausePlayer() {
        DebugLog.d("UnityPlayerWrapper: Pausing");
        mUnityPlayer.windowFocusChanged(false);
        mUnityPlayer.pause();
    }

    /**
     * Shuts down the {@code UnityPlayer}.
     * Note: this will kill the application process entirely.
     */
    public void quitPlayer() {
        DebugLog.d("UnityPlayerWrapper: Shutting down UnityPlayer");
        mUnityPlayer.quit();
    }

    /**
     * Handles the destruction of {@code UnityWallpaperEngine}-owned {@code SurfaceHolder}.
     *
     * @param surfaceHolder {@code UnityWallpaperEngine}-owned {@code SurfaceHolder} that was destroyed.
     */
    public void handleSurfaceDestroyed(SurfaceHolder surfaceHolder) {
        // We don't care about destruction of other surfaces except the one currently in use
        if (mSurfaceHolder != surfaceHolder)
            return;

        DebugLog.v(String.format(
            Locale.ENGLISH,
            "UnityPlayerWrapper: Handling SurfaceHolder (w: %1d, h: %2d) destruction",
            surfaceHolder == null ? -1 : surfaceHolder.getSurfaceFrame().width(),
            surfaceHolder == null ? -1 : surfaceHolder.getSurfaceFrame().height()));
        setPlayerSurface(null);
    }

    /**
     * Sets the primary rendering surface of {@code UnityPlayer}.
     *
     * @param surfaceHolder {@code SurfaceHolder} to set as primary surface. Set to null to detach the primary surface.
     */
    public void setPlayerSurface(SurfaceHolder surfaceHolder) {
        DebugLog.v(String.format(
            Locale.ENGLISH,
            "UnityPlayerWrapper: Updating Unity player surface (w: %1d, h: %2d)",
            surfaceHolder == null ? -1 : surfaceHolder.getSurfaceFrame().width(),
            surfaceHolder == null ? -1 : surfaceHolder.getSurfaceFrame().height()));
        mSurfaceHolder = surfaceHolder;
        setPlayerSurfaceDirect(surfaceHolder != null ? surfaceHolder.getSurface() : null);
    }

    /**
     * Forwards touch events to Unity.
     *
     * @param inputEvent
     */
    public boolean injectInputEvent(InputEvent inputEvent) {
        return mUnityPlayer.injectEvent(inputEvent);
    }

    /**
     * Forwards configuration changes to Unity.
     *
     * @param configuration
     */
    public void injectConfigurationChange(Configuration configuration) {
        mUnityPlayer.configurationChanged(configuration);
    }

    /**
     * Sets internal {@code UnityPlayer} reference to {@code ContextWrapper},
     * used for soft input and some other stuff.
     *
     * @param contextWrapper
     */
    public void setContext(ContextWrapper contextWrapper) {
        try {
            if (contextWrapper == null) {
                mUnityPlayerContextWrapperField.set(mUnityPlayer, mApplicationContext);
            } else {
                mUnityPlayerContextWrapperField.set(mUnityPlayer, contextWrapper);
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public static void setUnityPlayerCurrentActivity(Activity activity) {
        UnityPlayer.currentActivity = activity;
    }

    public static Activity getUnityPlayerCurrentActivity() {
        return UnityPlayer.currentActivity;
    }

    private void setPlayerSurfaceDirect(Surface surface) {
        mUnityPlayer.displayChanged(0, surface);
    }

    /**
     * Processes UnityPlayer instance to make it behave like if it actually wasn't launched from an Activity.
     *
     * @param contextWrapper
     */
    private void setupUnityPlayerInnerState(ContextWrapper contextWrapper) {
        // Completely detach Unity from Activity
        final Field[] playerFields = UnityPlayer.class.getDeclaredFields();
        for (Field field : playerFields) {
            // Unregister SurfaceView callbacks
            if (field.getType() == SurfaceView.class) {
                try {
                    field.setAccessible(true);
                    Object surfaceView = field.get(mUnityPlayer);
                    Field callbacksField = surfaceView.getClass().getDeclaredField("mCallbacks");
                    if (callbacksField == null) {
                        DebugLog.e("SurfaceView.mCallbacks field could not be found. Please report this.");
                    } else {
                        callbacksField.setAccessible(true);
                        List callbacks = (List) callbacksField.get(surfaceView);
                        callbacks.clear();
                    }
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
            // Unregister com.unity3d.intent.action.SHUTDOWN receiver
            // FIXME: should this be done at all?
            else if (field.getType() == BroadcastReceiver.class) {
                try {
                    field.setAccessible(true);
                    BroadcastReceiver shutdownReceiver = (BroadcastReceiver) field.get(mUnityPlayer);
                    contextWrapper.unregisterReceiver(shutdownReceiver);
                    field.set(mUnityPlayer, null);
                } catch (IllegalArgumentException e) {
                    if (!e.getMessage().contains("Receiver not registered")) {
                        e.printStackTrace();
                    }
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
            // Clear references to Activity and replace them with Application Context
            else if (field.getType() == ContextWrapper.class) {
                field.setAccessible(true);
                mUnityPlayerContextWrapperField = field;
                setContext(null);
            }
        }
    }

    /**
     * Makes Unity player code think it is being run on API < 23
     * by modifying some internal state.
     *
     * @throws Exception
     */
    private void disableConflictingApi23Support() throws Exception {
        // Make Unity think it is started on API < 23
        // 1. Search for interface with 1 method with arguments (Activity, Runnable)
        final Class[] classes = mUnityPlayerPackageClasses.getClasses();

        Class permissionRequestDialogInterface = null;
        for (Class clazz : classes) {
            try {
                if (!clazz.isInterface())
                    continue;

                Method[] methods = clazz.getDeclaredMethods();
                if (methods.length != 1)
                    continue;

                Method method = methods[0];
                if (method.getReturnType() != void.class)
                    continue;

                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length == 2 && parameterTypes[0] == Activity.class && parameterTypes[1] == Runnable.class) {
                    permissionRequestDialogInterface = method.getDeclaringClass();
                    break;
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }

        if (permissionRequestDialogInterface == null)
            throw new Exception("permissionRequestDialogInterface == null");

        // 2. Search for class that has a static field of that interface class
        Class apiVersionObjectsClass = null;
        Field apiVersionObjectsClassPermissionRequestDialogClassInstanceField = null;
        outerLoop:
        for (Class clazz : classes) {
            try {
                Field[] fields = clazz.getDeclaredFields();
                for (Field field : fields) {
                    if ((field.getModifiers() & Modifier.STATIC) == 0 || field.getType() != permissionRequestDialogInterface)
                        continue;

                    apiVersionObjectsClassPermissionRequestDialogClassInstanceField = field;
                    apiVersionObjectsClassPermissionRequestDialogClassInstanceField.setAccessible(true);
                    apiVersionObjectsClass = field.getDeclaringClass();
                    break outerLoop;
                }
            } catch (NoClassDefFoundError e) {
                // Ignore missing class definitions errors
            }
        }

        if (apiVersionObjectsClass == null)
            throw new Exception("apiVersionObjectsClass == null");

        apiVersionObjectsClassPermissionRequestDialogClassInstanceField.set(null, null);

        // 3. Search for field that corresponds for API 23
        List<Field> apiVersionObjectsClassApiVersionFields = new ArrayList<>();
        final Field[] apiVersionObjectsClassFields = apiVersionObjectsClass.getDeclaredFields();
        if (apiVersionObjectsClassFields.length == 0)
            throw new Exception("apiVersionObjectsClassFields.length == 0");

        final int[] fieldsApiVersions;
        if (UnityVersionInfo.getInstance().isUnity550orNewer()) {
            fieldsApiVersions = new int[]{ 21, 23 };
        } else if (UnityVersionInfo.getInstance().isUnity540orNewer()) {
            fieldsApiVersions = new int[]{ 11, 17, 19, 21, 23 };
        } else {
            fieldsApiVersions = new int[]{ 11, 12, 14, 16, 17, 19, 21, 23 };
        }

        final int searchedApiVersion = 23;
        int searchedApiVersionFieldIndex = -1;
        for (int i = 0; i < fieldsApiVersions.length; i++) {
            if (fieldsApiVersions[i] == searchedApiVersion) {
                searchedApiVersionFieldIndex = i;
                break;
            }
        }

        for (Field field : apiVersionObjectsClassFields) {
            if ((field.getModifiers() & Modifier.STATIC) == 0 || field.getType() != boolean.class)
                continue;

            field.setAccessible(true);
            apiVersionObjectsClassApiVersionFields.add(field);
        }

        if (apiVersionObjectsClassApiVersionFields.size() == 0)
            throw new Exception("apiVersionObjectsClassApiVersionFields.size() == 0");

        boolean isApiVersionFieldDisabled = false;
        for (int i = 0; i < apiVersionObjectsClassApiVersionFields.size(); i++) {
            Field field = apiVersionObjectsClassApiVersionFields.get(i);
            boolean fieldValue = field.getBoolean(null);
            if (i == searchedApiVersionFieldIndex && fieldValue) {
                field.setBoolean(null, false);
                isApiVersionFieldDisabled = true;
                break;
            }
        }

        if (!isApiVersionFieldDisabled)
            throw new Exception("isApiVersionFieldDisabled == false");
    }

    private final class UnityPlayerPackageClasses {
        private final Class[] mClasses;

        public UnityPlayerPackageClasses(Context context) {
            // Get all classes in com.unity3d.player package
            final String unityPlayerPackage = "com.unity3d.player";
            Class[] initialClasses = ReflectionUtility.getClassesOfPackage(context, unityPlayerPackage);
            HashSet<Class> classes = new HashSet<>(Arrays.asList(initialClasses));

            // HACK: when debugging, Gradle 2.0 outputs strange APKs from which it's impossible to get the full list of classes.
            // Unity player Java library is minified, so most classes have names like com.unity3d.player.X
            // Just iterate over all possible one-letter class names and hope for the best.

            // All lower- and uppercase Latin letters
            final char[] alphabet = ("abcdefghijklmnopqrstuvwxyz" + "abcdefghijklmnopqrstuvwxyz".toUpperCase(Locale.US)).toCharArray();
            for (char alphabetLetter : alphabet) {
                try {
                    classes.add(Class.forName(unityPlayerPackage + "." + alphabetLetter));
                } catch (ClassNotFoundException e) {
                    // Ignore
                }
            }

            mClasses = classes.toArray(new Class[classes.size()]);
        }

        public Class[] getClasses() {
            return mClasses;
        }
    }

    /**
     * Manages internal UnityPlayer Choreographer listener.
     *
     * Unity uses Choreographer on API >= 16 in order to synchronize render with display refreshes.
     * This is nice, but for some reason the listener is not unregistered when the application goes
     * to background. Besides, vertical synchronization is not something you'd want in a wallpaper,
     * as it would introduce certain input lag.
     */
    private final class VSyncManagerWrapper {

        /**
         * Instance of Unity internal VSync manager.
         */
        private Object mVSyncManager;

        /**
         * Method in {@code VSyncManager} that enables listening for Choreographer events.
         */
        private Method mVSyncLockMethod;

        /**
         * Method in {@code VSyncManager} that disables listening for Choreographer events.
         */
        private Method mVSyncUnlockMethod;

        /**
         * Indicates whether the instances of Unity vsync manager and its methods were found.
         */
        private boolean mIsInitialized = false;
        private boolean mIsLocked = true;

        public VSyncManagerWrapper() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                DebugLog.d("API level < 16, Choreographer not available, exiting VSyncManagerWrapper constructor");
                return;
            }

            // Use some clever heuristics to find the stuff we need via Reflection
            try {
                final Class[] classes = mUnityPlayerPackageClasses.getClasses();

                Class<?> vSyncManagerClass = null;
                Method vSyncLockMethod = null;
                Method vSyncUnlockMethod = null;
                // Search for interface with 2 methods:
                // 1: void with no arguments
                // 2: void with UnityPlayer argument
                outerLoop:
                for (Class clazz : classes) {
                    boolean isLockMethodFound = false;
                    boolean isUnlockMethodFound = false;
                    vSyncLockMethod = null;
                    vSyncUnlockMethod = null;
                    try {
                        if (!clazz.isInterface())
                            continue;

                        Method[] methods = clazz.getDeclaredMethods();
                        if (methods.length != 2 && methods.length != 4)
                            continue;

                        for (Method method : methods) {
                            if (method.getReturnType() != void.class)
                                break;

                            Class<?>[] parameterTypes = method.getParameterTypes();
                            if (parameterTypes.length == 0) {
                                vSyncUnlockMethod = method;
                                isUnlockMethodFound = true;
                                if (isLockMethodFound && isUnlockMethodFound) {
                                    vSyncManagerClass = clazz;
                                    break outerLoop;
                                }

                                continue;
                            }

                            if (parameterTypes.length == 1 && parameterTypes[0] == UnityPlayer.class) {
                                vSyncLockMethod = method;
                                isLockMethodFound = true;
                                if (isLockMethodFound && isUnlockMethodFound) {
                                    vSyncManagerClass = clazz;
                                    break outerLoop;
                                }
                            }
                        }
                    } catch (NoClassDefFoundError e) {
                        // Ignore missing class definitions errors
                    }
                }

                if (vSyncManagerClass == null)
                    throw new Exception("VSyncManager interface type not found");

                // We have found the interface type. Now find a class that has a static field
                // of that interface type and retrieve the value of that field
                Object vSyncManager = null;

                outerLoop:
                for (Class clazz : classes) {
                    try {
                        Field[] fields = clazz.getDeclaredFields();
                        for (Field field : fields) {
                            if ((field.getModifiers() & Modifier.STATIC) == 0 || field.getType() != vSyncManagerClass)
                                continue;

                            field.setAccessible(true);
                            vSyncManager = field.get(null);
                            break outerLoop;
                        }
                    } catch (NoClassDefFoundError e) {
                        // Ignore missing class definitions errors
                    }
                }

                if (vSyncManager == null)
                    throw new Exception("VSyncManager instance not found");

                DebugLog.v("VSyncManager instance found");

                // Save the retrieved references
                mVSyncManager = vSyncManager;
                mVSyncLockMethod = vSyncLockMethod;
                mVSyncUnlockMethod = vSyncUnlockMethod;
                mIsInitialized = true;
            } catch (Throwable e) {
                DebugLog.e(
                    "Unable to initialize VSyncManagerWrapper. " +
                    "This will lead to more battery drain when live wallpaper is in the background. " +
                    "Please report this.");
                e.printStackTrace();
            }
        }

        /**
         * Enables listening for Choreographer events.
         */
        public void registerVSyncListener() {
            if (!mIsInitialized || mIsLocked)
                return;

            try {
                mVSyncLockMethod.invoke(mVSyncManager, UnityPlayerWrapper.this.mUnityPlayer);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }

        /**
         * Disables listening for Choreographer events.
         */
        public void unregisterVSyncListener() {
            if (!mIsInitialized || !mIsLocked)
                return;

            try {
                mVSyncUnlockMethod.invoke(mVSyncManager);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }
}
