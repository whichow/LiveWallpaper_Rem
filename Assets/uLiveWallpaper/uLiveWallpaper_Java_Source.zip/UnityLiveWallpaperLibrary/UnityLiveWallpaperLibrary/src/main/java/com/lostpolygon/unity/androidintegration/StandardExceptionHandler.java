/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import android.util.Log;

/**
 * Uncaught exception handler that logs the exception to System.err stream.
 * Note: Unity takes over the default uncaught exception handler. On some devices
 * this results to stack traces not being printed partially or entirely.
 */
public class StandardExceptionHandler implements Thread.UncaughtExceptionHandler {
    private static StandardExceptionHandler mInstance = new StandardExceptionHandler();

    private final Thread.UncaughtExceptionHandler mDefaultUncaughtExceptionHandler;
    private boolean mIsAttached;

    public static StandardExceptionHandler getInstance() {
        return mInstance;
    }

    private StandardExceptionHandler() {
        // Get the current default handler
        mDefaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
    }

    /**
     * Sets {@code StandardExceptionHandler} as default uncaught exception handler.
     */
    public void attach() {
        // Only try to attach once
        if (mIsAttached)
            return;

        Thread.setDefaultUncaughtExceptionHandler(this);
        mIsAttached = true;
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        // Log the exception to System.err and forward the exception to saved default handler
        System.err.print(Log.getStackTraceString(ex));

        mDefaultUncaughtExceptionHandler.uncaughtException(thread, ex);
    }
}
