package com.lostpolygon.unity.androidintegration;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

/**
 * Stores information about capabilities of Unity player from different Unity versions.
 */
public final class UnityVersionInfo {
    private static UnityVersionInfo sInstance;

    private final String mUnityVersion;
    private final boolean mIsUnityNonActivityConstructorBugFixed;
    private final boolean mHasApi23PermissionRequestSupport;
    private final boolean mIsUnity540orNewer;
    private final boolean mIsUnity550orNewer;

    private UnityVersionInfo(String unityVersion) {
        mUnityVersion = unityVersion;
        mIsUnityNonActivityConstructorBugFixed = versionCompare(unityVersion, "5.3.6") >= 0;
        mHasApi23PermissionRequestSupport = versionCompare(unityVersion, "5.2.4") >= 0;
        mIsUnity540orNewer = versionCompare(unityVersion, "5.4.0") >= 0;
        mIsUnity550orNewer = versionCompare(unityVersion, "5.5.0") >= 0;
    }

    public String getUnityVersion() {
        return mUnityVersion;
    }

    /**
     * Since Unity 4.0.2, calling {@code new UnityPlayer()} with non-Activity Context as an argument
     * resulted in an immediate crash. This bug was fixed in Unity 5.3.6.
     * @return
     */
    public boolean isUnityNonActivityConstructorBugFixed() {
        return mIsUnityNonActivityConstructorBugFixed;
    }

    /**
     * Since Unity 5.2.4, on API23+ Unity shows a permission request dialog.
     * @return
     */
    public boolean hasApi23PermissionRequestSupport() {
        return mHasApi23PermissionRequestSupport;
    }

    public boolean isUnity550orNewer() {
        return mIsUnity550orNewer;
    }

    public boolean isUnity540orNewer() {
        return mIsUnity540orNewer;
    }

    public static UnityVersionInfo getInstance() {
        return sInstance;
    }

    public static void updateUnityVersionIfNeeded(Context context) {
        if (sInstance != null)
            return;

        // Unity version string is contained in <meta-data> inside <application>.
        final String metaDataName = "uLiveWallpaper.UnityVersion";

        final PackageManager packageManager = context.getPackageManager();
        final ApplicationInfo applicationInfo;
        try {
            applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            DebugLog.e("UnityVersionInfo: Unable to retrieve ApplicationInfo. This should not ever happen.");
            return;
        }

        if (applicationInfo.metaData != null && applicationInfo.metaData.containsKey(metaDataName)) {
            try {
                final String unityVersion = (String) applicationInfo.metaData.get(metaDataName);
                sInstance = new UnityVersionInfo(unityVersion);
                return;
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }

        final String minimalUnityVersion = "5.1.3";
        DebugLog.e("No <meta-data> tag with name 'uLiveWallpaper.UnityVersion' found, assuming Unity " + minimalUnityVersion);

        // No <meta-data> element was found, fall back to lowest supported Unity version
        sInstance = new UnityVersionInfo(minimalUnityVersion);
    }

    /**
     * Sets current instance to the one with new Unity version string.
     * @param unityVersion Unity version string.
     */
    private static void setUnityVersion(String unityVersion) {
        sInstance = new UnityVersionInfo(unityVersion);
    }

    /**
     * Compares two version strings.
     *
     * Use this instead of String.compareTo() for a non-lexicographical
     * comparison that works for version strings. e.g. "1.10".compareTo("1.6").
     *
     * @note It does not work if "1.10" is supposed to be equal to "1.10.0".
     *
     * @param str1 a string of ordinal numbers separated by decimal points.
     * @param str2 a string of ordinal numbers separated by decimal points.
     * @return The result is a negative integer if str1 is _numerically_ less than str2.
     *         The result is a positive integer if str1 is _numerically_ greater than str2.
     *         The result is zero if the strings are _numerically_ equal.
     */
    private static int versionCompare(String str1, String str2) {
        String[] vals1 = str1.split("\\.");
        String[] vals2 = str2.split("\\.");
        int i = 0;
        // set index to first non-equal ordinal or length of shortest version string
        while (i < vals1.length && i < vals2.length && vals1[i].equals(vals2[i])) {
            i++;
        }
        // compare first non-equal ordinal number
        if (i < vals1.length && i < vals2.length) {
            int diff = Integer.valueOf(vals1[i]).compareTo(Integer.valueOf(vals2[i]));
            return Integer.signum(diff);
        }
        // the strings are equal or one string is a substring of the other
        // e.g. "1.2.3" = "1.2.3" or "1.2.3" < "1.2.3.4"
        return Integer.signum(vals1.length - vals2.length);
    }
}
