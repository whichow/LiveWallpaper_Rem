/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.livewallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Point;
import android.os.Build;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import com.lostpolygon.unity.androidintegration.DebugLog;
import com.lostpolygon.unity.androidintegration.MultiTapDetector;
import com.lostpolygon.unity.androidintegration.StandardExceptionHandler;
import com.lostpolygon.unity.androidintegration.UnityPlayerHolder;
import com.lostpolygon.unity.androidintegration.UnityPlayerInstanceManager;
import com.lostpolygon.unity.androidintegration.UnityPlayerWrapper;
import com.lostpolygon.unity.androidintegration.UnityPlayerWrapperInstantiator;
import com.lostpolygon.unity.androidintegration.UnityVersionInfo;

/**
 * Service representing the live wallpaper with Unity backend.
 */
public abstract class UnityWallpaperService extends WallpaperService {
    private final UnityEventsProxy mUnityEventsProxy = LiveWallpaperUnityFacade.getEventsProxy();
    private final BroadcastReceiver mScreenOnOffReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case Intent.ACTION_SCREEN_ON:
                    onScreenOn();
                    break;
                case Intent.ACTION_SCREEN_OFF:
                    onScreenOff();
                    break;
            }
        }
    };

    private UnityPlayerWrapper mUnityPlayerWrapper;
    private LiveWallpaperUnityFacade mLiveWallpaperUnityFacade;
    private UnityPlayerInstanceManager mUnityPlayerInstanceManager;

    /**
     * Whether at least one wallpaper engine was visible when screen turned off.
     */
    private boolean mIsWallpaperVisibleBeforeScreenOff;

    @Override
    public void onCreate() {
        // Update Unity version info
        UnityVersionInfo.updateUnityVersionIfNeeded(this);

        DebugLog.logStartupMessage();
        DebugLog.v("UnityWallpaperService.onCreate");

        // Attach the {@code StandardExceptionHandler} to get better exception logs.
        StandardExceptionHandler.getInstance().attach();

        // Register the screen on/off broadcast listener
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mScreenOnOffReceiver, filter);
    }

    @Override
    public void onDestroy() {
        DebugLog.d("UnityWallpaperService.onDestroy");

        unregisterReceiver(mScreenOnOffReceiver);

        // {@code UnityPlayer} is destroyed together with {@code UnityWallpaperService}.
        // The side effect is that not only {@code UnityWallpaperService} is destroyed,
        // but the whole application process dies.
        UnityPlayerWrapper unityPlayerWrapper = UnityPlayerInstanceManager.getInstance().getUnityPlayerWrapperInstance();
        if (unityPlayerWrapper != null && UnityPlayerInstanceManager.getInstance().getUnityPlayerPauseResumeManager().getUnityPlayerHoldersCount() == 0) {
            unityPlayerWrapper.quitPlayer();
        }
    }

    @Override
    public Engine onCreateEngine() {
        // Even though there can only be a single instance of {@code UnityPlayer},
        // there can be multiple {@code UnityWallpaperEngine} active at same time,
        // for example, when in preview mode.
        return new UnityWallpaperEngine();
    }

    /**
     * @return Whether screen on and off events should be accounted for resuming and pausing the Unity Player.
     * Override this to returns false if you run into issues.
     */
    protected boolean useScreenOnOffAsVisibilityChangedWorkaround() {
        return true;
    }

    /**
     * @return Whether to destroy the live wallpaper service if all wallpaper engines got destroyed.
     * For some reason, when Preview screen is started first, the wallpaper service is not destroyed automatically.
     * Override this to return false if you run into issues.
     */
    protected boolean useServiceDestroyWorkaround() {
        return true;
    }

    /**
     * Called when device screen is turned on.
     */
    private void onScreenOn() {
        if (!useScreenOnOffAsVisibilityChangedWorkaround())
            return;

        DebugLog.v("UnityWallpaperService: SCREEN_ON");

        boolean isWallpaperVisibleBeforeScreenOff = mIsWallpaperVisibleBeforeScreenOff;
        mIsWallpaperVisibleBeforeScreenOff = false;

        // Send fake onVisibilityChanged(true) event to current wallpaper engine, if needed
        if (!isWallpaperVisibleBeforeScreenOff)
            return;

        DebugLog.d("Wallpaper was visible before screen off, sending onVisibilityChanged(true)");
        if (mLiveWallpaperUnityFacade == null)
            return;

        final UnityPlayerHolder activeUnityPlayerHolder = mUnityPlayerInstanceManager.getActiveUnityPlayerHolder();
        if (activeUnityPlayerHolder == null)
            return;

        final UnityWallpaperEngine activeWallpaperEngine = mLiveWallpaperUnityFacade.getActiveWallpaperEngine();
        if (activeWallpaperEngine == null || activeWallpaperEngine.getUnityPlayerHolder() != activeUnityPlayerHolder)
            return;

        activeWallpaperEngine.onVisibilityChanged(true);
    }

    /**
     * Called when device screen is turned off.
     */
    private void onScreenOff() {
        if (!useScreenOnOffAsVisibilityChangedWorkaround() || mUnityPlayerInstanceManager.getUnityPlayerPauseResumeManager().getUnityPlayerHoldersCount() == 0)
            return;

        DebugLog.v("UnityWallpaperService: SCREEN_OFF");

        // Send fake onVisibilityChanged(false) event to current wallpaper engine, if needed
        mIsWallpaperVisibleBeforeScreenOff = false;
        if (mLiveWallpaperUnityFacade == null)
            return;

        if (mUnityPlayerInstanceManager.getUnityPlayerPauseResumeManager().getVisibleUnityPlayerHoldersCount() > 0) {
            mIsWallpaperVisibleBeforeScreenOff = true;

            final UnityPlayerHolder activeUnityPlayerHolder = mUnityPlayerInstanceManager.getActiveUnityPlayerHolder();
            if (activeUnityPlayerHolder == null)
                return;

            final UnityWallpaperEngine activeWallpaperEngine = mLiveWallpaperUnityFacade.getActiveWallpaperEngine();
            if (activeWallpaperEngine == null || activeWallpaperEngine.getUnityPlayerHolder() != activeUnityPlayerHolder)
                return;

            DebugLog.d("Screen off, sending onVisibilityChanged(false)");
            activeWallpaperEngine.onVisibilityChanged(false);
        } else {
            DebugLog.v("Screen off, but visibleUnityPlayerHoldersCount == 0, not sending onVisibilityChanged(false)");
        }
    }

    /**
     * Wallpaper engine that uses Unity.
     */
    public class UnityWallpaperEngine extends Engine implements MultiTapDetector.IMultiTapDetectedListener {
        private UnityPlayerHolder mUnityPlayerHolder;

        /**
         * Last known {@code SurfaceHolder} provided to this engine.
         */
        private SurfaceHolder mCurrentSurfaceHolder;

        public UnityWallpaperEngine() {
            final UnityPlayerWrapperInstantiator unityPlayerWrapperInstantiator = new UnityPlayerWrapperInstantiator(UnityWallpaperService.this) {
                @Override
                public boolean isVisible() {
                    return UnityWallpaperEngine.this.isVisible();
                }

                @Override
                public SurfaceHolder getSurfaceHolder() {
                    return mCurrentSurfaceHolder;
                }

                @Override
                public void onAlreadyInstantiated() {
                    mUnityPlayerInstanceManager = UnityPlayerInstanceManager.getInstance();
                    mLiveWallpaperUnityFacade = LiveWallpaperUnityFacade.getInstance();
                }

                @Override
                public void onUnityPlayerInstanceCreated() {
                    onAlreadyInstantiated();
                    mLiveWallpaperUnityFacade.setActiveWallpaperEngine(UnityWallpaperEngine.this);
                }

                @Override
                public void onSetUnityPlayerWrapper(UnityPlayerWrapper unityPlayerWrapper) {
                    mUnityPlayerWrapper = unityPlayerWrapper;
                }

                @Override
                public void onSetUnityPlayerHolder(UnityPlayerHolder unityPlayerHolder) {
                    mUnityPlayerHolder = unityPlayerHolder;
                }
            };

            unityPlayerWrapperInstantiator.instantiate();

            // Enable event listening
            setTouchEventsEnabled(true);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
                setOffsetNotificationsEnabled(true);
            }
        }

        public UnityPlayerHolder getUnityPlayerHolder() {
            return mUnityPlayerHolder;
        }

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);

            log("UnityWallpaperEngine.onCreate");
        }

        @Override
        public void onDestroy() {
            super.onDestroy();

            log("UnityWallpaperEngine.onDestroy");

            // Clear the current engine reference
            if (mLiveWallpaperUnityFacade != null) {
                if (mLiveWallpaperUnityFacade.getActiveWallpaperEngine() == this) {
                    mLiveWallpaperUnityFacade.setActiveWallpaperEngine(null);
                }

                if (mUnityPlayerInstanceManager.getActiveUnityPlayerHolder() == mUnityPlayerHolder) {
                    mUnityPlayerInstanceManager.setActiveUnityPlayerHolder(null);
                }
            }

            mUnityPlayerHolder.unregister();

            if (useServiceDestroyWorkaround()) {
                final int unityPlayerHoldersCount = mUnityPlayerInstanceManager.getUnityPlayerPauseResumeManager().getUnityPlayerHoldersCount();
                log("unityPlayerHoldersCount == " + unityPlayerHoldersCount, true);
                if (unityPlayerHoldersCount == 0) {
                    log("unityPlayerHoldersCount == 0, stopping service", true);
                    UnityWallpaperService.this.stopSelf();
                }
            }
        }

        @Override
        public void onTouchEvent(MotionEvent motionEvent) {
            if (mUnityPlayerWrapper == null)
                return;

            if (mLiveWallpaperUnityFacade != null) {
                mLiveWallpaperUnityFacade.getMultiTapDetector().onTouchEvent(motionEvent);
            }

            // Forward touch events to Unity
            mUnityPlayerWrapper.injectInputEvent(motionEvent);
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
            if (mUnityEventsProxy == null)
                return;

            // Pass event to C#
            mUnityEventsProxy.offsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset);
        }

        @Override
        public void onDesiredSizeChanged(int desiredWidth, int desiredHeight) {
            if (mUnityEventsProxy == null)
                return;

            // Pass event to C#
            if (mLiveWallpaperUnityFacade == null || mLiveWallpaperUnityFacade.getActiveWallpaperEngine() == this) {
                mUnityEventsProxy.desiredSizeChanged(desiredWidth, desiredHeight);
            }
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);

            log("UnityWallpaperEngine.onVisibilityChanged: " + visible);

            if (visible) {
                // Setup
                if (mLiveWallpaperUnityFacade != null) {
                    mLiveWallpaperUnityFacade.setActiveWallpaperEngine(this);
                    mUnityPlayerInstanceManager.setActiveUnityPlayerHolder(mUnityPlayerHolder);
                    mLiveWallpaperUnityFacade.getMultiTapDetector().registerMultiTapDetectedListener(this);
                    mLiveWallpaperUnityFacade.getMultiTapDetector().setScreenSize(new Point(getDesiredMinimumWidth(), getDesiredMinimumHeight()));
                }

                mUnityPlayerHolder.onVisibilityChanged(true, mCurrentSurfaceHolder);

                // Send events to C#
                mUnityEventsProxy.desiredSizeChanged(getDesiredMinimumWidth(), getDesiredMinimumHeight());
                mUnityEventsProxy.visibilityChanged(true);
                mUnityEventsProxy.isPreviewChanged(isPreview());
            } else {
                if (mLiveWallpaperUnityFacade != null) {
                    mLiveWallpaperUnityFacade.getMultiTapDetector().unregisterMultiTapDetectedListener(this);
                }

                // Send events to C#.
                // Do this before Unity was paused to avoid them being received in paused state
                if (mLiveWallpaperUnityFacade == null || mUnityPlayerInstanceManager.getActiveUnityPlayerHolder() == mUnityPlayerHolder) {
                    mUnityEventsProxy.visibilityChanged(false);
                }

                mUnityPlayerHolder.onVisibilityChanged(false, null);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder surfaceHolder, int format, int width, int height) {
            super.onSurfaceChanged(surfaceHolder, format, width, height);

            log("UnityWallpaperEngine.onSurfaceChanged", true);

            // Save reference to the current SurfaceHolder
            mCurrentSurfaceHolder = surfaceHolder;
            if (mUnityPlayerWrapper == null)
                return;

            // Update the UnityPlayer surface
            mUnityPlayerWrapper.setPlayerSurface(surfaceHolder);
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder surfaceHolder) {
            super.onSurfaceCreated(surfaceHolder);

            log("UnityWallpaperEngine.onSurfaceCreated", true);

            // Save reference to the current SurfaceHolder
            mCurrentSurfaceHolder = surfaceHolder;
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder surfaceHolder) {
            super.onSurfaceDestroyed(surfaceHolder);

            log("UnityWallpaperEngine.onSurfaceDestroyed", true);
            if (mUnityPlayerWrapper == null)
                return;

            mUnityPlayerWrapper.handleSurfaceDestroyed(surfaceHolder);
        }

        @Override
        public void onMultiTapDetected(float finalTapPositionX, float finalTapPositionY) {
            mUnityEventsProxy.multiTapDetected(finalTapPositionX, finalTapPositionY);
        }

        private void log(Object obj) {
            log(obj, false);
        }

        private void log(Object obj, final boolean isVerbose) {
            String message = "";
            message += isPreview() ? "preview" : "wallpaper";
            if (BuildConfig.DEBUG) {
                message += "@";
                message += Integer.toHexString(hashCode());
            }
            message += ": ";
            message += obj == null ? "null" : obj.toString();
            if (isVerbose) {
                DebugLog.v(message);
            } else {
                DebugLog.d(message);
            }
        }
    }
}