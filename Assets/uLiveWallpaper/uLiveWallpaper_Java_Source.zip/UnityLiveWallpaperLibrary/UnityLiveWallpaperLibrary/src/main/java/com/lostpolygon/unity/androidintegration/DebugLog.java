/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import java.text.SimpleDateFormat;
import java.util.Locale;

import android.util.Log;

import com.lostpolygon.unity.livewallpaper.BuildConfig;

/**
 * Simple Log wrapper for internal usage.
 */
public final class DebugLog {
    public static final boolean ENABLED = true || BuildConfig.DEBUG;
    public static final boolean VERBOSE_ENABLED = false || BuildConfig.DEBUG;
    private static final String TAG = "UnityLWP";
    private static boolean sStartupMessageLogged;

    public static void d(final Object obj) {
        if (!ENABLED)
            return;

        Log.d(TAG, getMessage(obj));
    }

    public static void v(final Object obj) {
        if (!VERBOSE_ENABLED)
            return;

        Log.v(TAG, getMessage(obj));
    }

    public static void e(final Object obj) {
        if (!ENABLED)
            return;

        Log.e(TAG, getMessage(obj));
    }

    public static void logStartupMessage() {
        if (sStartupMessageLogged)
            return;

        sStartupMessageLogged = true;
        DebugLog.d(
            String.format(
                "Starting %1s v%2s %3s (Unity v%4s), built at %5s",
                BuildConfig.PROJECT_NAME,
                BuildConfig.VERSION_NAME,
                BuildConfig.BUILD_TYPE,
                UnityVersionInfo.getInstance().getUnityVersion(),
                new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US).format(BuildConfig.BUILD_DATE)
            )
        );
    }

    private static String getMessage(final Object obj) {
        return obj == null ? "null" : obj.toString();
    }
}
