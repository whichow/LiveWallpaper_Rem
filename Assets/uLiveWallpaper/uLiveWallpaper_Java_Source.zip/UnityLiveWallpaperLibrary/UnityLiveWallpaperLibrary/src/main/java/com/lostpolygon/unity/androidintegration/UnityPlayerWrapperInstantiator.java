package com.lostpolygon.unity.androidintegration;

import android.content.ContextWrapper;
import android.view.SurfaceHolder;

/**
 * Creates the Unity player instance and fires callbacks at important points of this process.
 */
public abstract class UnityPlayerWrapperInstantiator {
    private final ContextWrapper mContextWrapper;
    private UnityPlayerHolder mUnityPlayerHolder;
    private UnityPlayerWrapper mUnityPlayerWrapper;

    public UnityPlayerWrapperInstantiator(ContextWrapper contextWrapper) {
        mContextWrapper = contextWrapper;
    }

    public void instantiate() {
        final UnityPlayerInstanceManager unityPlayerInstanceManager = UnityPlayerInstanceManager.getInstance();
        mUnityPlayerHolder = unityPlayerInstanceManager.createUnityPlayerHolder();
        mUnityPlayerWrapper = unityPlayerInstanceManager.getUnityPlayerWrapperInstance();

        onSetUnityPlayerHolder(mUnityPlayerHolder);

        if (mUnityPlayerWrapper == null) {
            // If null, register a UnityPlayerWrapper creation listener
            // and submit a request to create UnityPlayerWrapper
            // FIXME: possible situation when multiple engines are created before UnityPlayer is created?
            DebugLog.d("UnityPlayerWrapper == null, trying to create it");
            unityPlayerInstanceManager.registerUnityPlayerInstanceCreatedListener(new IUnityPlayerInstanceCreatedListener() {
                @Override
                public void onUnityPlayerInstanceCreated() {
                    DebugLog.v("UnityPlayerWrapper creation event received");

                    // Cache references
                    mUnityPlayerWrapper = unityPlayerInstanceManager.getUnityPlayerWrapperInstance();
                    onSetUnityPlayerWrapper(mUnityPlayerWrapper);
                    UnityPlayerWrapperInstantiator.this.onUnityPlayerInstanceCreated();
                    unityPlayerInstanceManager.setActiveUnityPlayerHolder(mUnityPlayerHolder);
                }
            });

            // Attempt to create the UnityPlayer
            unityPlayerInstanceManager.requestCreateUnityPlayer(mContextWrapper);
        } else {
            onSetUnityPlayerWrapper(mUnityPlayerWrapper);
            onAlreadyInstantiated();
            DebugLog.d("mUnityPlayerWrapper != null, starting right away");
        }
    }

    protected abstract boolean isVisible();

    protected abstract SurfaceHolder getSurfaceHolder();

    protected abstract void onAlreadyInstantiated();

    protected abstract void onUnityPlayerInstanceCreated();

    protected abstract void onSetUnityPlayerWrapper(UnityPlayerWrapper unityPlayerWrapper);

    protected abstract void onSetUnityPlayerHolder(UnityPlayerHolder unityPlayerHolder);
}
