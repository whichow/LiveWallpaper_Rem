package com.lostpolygon.unity.androidintegration;

import java.util.HashSet;
import java.util.Set;

import android.view.SurfaceHolder;

/**
 * Stores list of {@code UnityPlayerHolder } and pauses/resumes the Unity player.
 * Unity player's main loop is only active when at least one {@code UnityPlayerHolder} is visible.
 */
public class UnityPlayerPauseResumeManager {
    /**
     * Contains {@code UnityPlayerHolder } instances.
     */
    private final Set<UnityPlayerHolder> mUnityPlayerHolders = new HashSet<>();

    /**
     * Managed {@code UnityPlayerWrapper}
     */
    private UnityPlayerWrapper mUnityPlayerWrapper;

    /**
     * Number of visible {@code UnityPlayerHolder} at the end of last {@code handleUnityPlayerHolderVisibilityChanged} call.
     */
    private int mVisibleHoldersCountPrev;

    /**
     * Whether Unity Player is currently paused.
     */
    private boolean mIsPaused;

    public void setUnityPlayerWrapper(UnityPlayerWrapper unityPlayerWrapper) {
        mUnityPlayerWrapper = unityPlayerWrapper;
    }

    /**
     * Must be called when {@code UnityPlayerHolder} changes its visibility state.
     * @param unityPlayerHolder {@code UnityPlayerHolder} that has changed its state
     * @param newSurfaceHolder Can be null.
     * @return Whether the Unity player has actually changed .
     */
    public boolean handleUnityPlayerHolderVisibilityChanged(UnityPlayerHolder unityPlayerHolder, SurfaceHolder newSurfaceHolder) {
        // Add the {@code UnityPlayerHolder} to the list
        mUnityPlayerHolders.add(unityPlayerHolder);
        int visibleHoldersCount = getVisibleUnityPlayerHoldersCount();

        if (mUnityPlayerWrapper == null) {
            mVisibleHoldersCountPrev = visibleHoldersCount;
            return false;
        }

        DebugLog.v("UnityPlayerPauseResumeManager: visibleHoldersCount: " + visibleHoldersCount);

        boolean isChangesApplied = false;

        // TODO: improve case when surface updated while Unity has not yet initialized the context
        //if (surfaceHolder != null && mSurfaceHolder != surfaceHolder) {
        if (newSurfaceHolder != null) {
            mUnityPlayerWrapper.setPlayerSurface(newSurfaceHolder);
        }

        // Only change the actual state when needed
        if (visibleHoldersCount != mVisibleHoldersCountPrev) {
            isChangesApplied = true;
            mIsPaused = visibleHoldersCount <= 0;
            if (!mIsPaused) {
                mUnityPlayerWrapper.resumePlayer();
            } else {
                mUnityPlayerWrapper.pausePlayer();
            }
        }

        mVisibleHoldersCountPrev = visibleHoldersCount;

        return isChangesApplied;
    }

    /**
     * Must be called when wallpaper engine is destroyed to correctly handle its destruction.
     * @param unityPlayerHolder
     */
    public void unregisterUnityPlayerHolder(UnityPlayerHolder unityPlayerHolder) {
        mUnityPlayerHolders.remove(unityPlayerHolder);
    }

    /**
     * @return Number of currently visible {@code UnityPlayerHolder}.
     */
    public int getVisibleUnityPlayerHoldersCount() {
        int count = 0;
        for (UnityPlayerHolder entry : mUnityPlayerHolders) {
            if (entry.isVisible())
                count++;
        }

        return count;
    }

    /**
     * @return Number of currently registered {@code UnityPlayerHolder}.
     */
    public int getUnityPlayerHoldersCount() {
        return mUnityPlayerHolders.size();
    }

    /**
     * @return Whether Unity Player is currently paused.
     */
    public boolean isUnityPlayerPaused() {
        return mIsPaused;
    }
}
