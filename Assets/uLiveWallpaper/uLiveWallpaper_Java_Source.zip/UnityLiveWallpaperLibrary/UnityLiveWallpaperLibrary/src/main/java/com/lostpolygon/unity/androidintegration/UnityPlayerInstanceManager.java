/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;

/**
 * Manages creation of {@code UnityPlayerWrapper} and notifies the listener about this event.
 */
public final class UnityPlayerInstanceManager {
    private static UnityPlayerInstanceManager sInstance;

    private final ArrayList<IUnityPlayerInstanceCreatedListener> mUnityPlayerInstanceCreatedListeners = new ArrayList<>();
    private final UnityPlayerPauseResumeManager mUnityPlayerPauseResumeManager = new UnityPlayerPauseResumeManager();

    /**
     * Currently active {@code UnityWallpaperService.UnityPlayerHolder}, or null if none is active.
     */
    private UnityPlayerHolder mActiveUnityPlayerHolder;

    /**
     * {@code UnityPlayerWrapper} instance. There could be only one.
     */
    private UnityPlayerWrapper mUnityPlayerWrapper;

    public static UnityPlayerInstanceManager getInstance() {
        if (sInstance == null) {
            sInstance = new UnityPlayerInstanceManager();
        }

        return sInstance;
    }

    /**
     * Gets the {@code UnityPlayerWrapper} instance.
     * @return {@code UnityPlayerWrapper} instance, or null if it is not instantiated yet.
     */
    public synchronized UnityPlayerWrapper getUnityPlayerWrapperInstance() {
        return mUnityPlayerWrapper;
    }

    public UnityPlayerPauseResumeManager getUnityPlayerPauseResumeManager() {
        return mUnityPlayerPauseResumeManager;
    }

    public boolean getIsUnityPlayerPaused() {
        return mUnityPlayerWrapper == null || mUnityPlayerPauseResumeManager.isUnityPlayerPaused();
    }

    /**
     * @return Currently active {@code UnityPlayerHolder}, or null if none is active.
     */
    public UnityPlayerHolder getActiveUnityPlayerHolder() {
        return mActiveUnityPlayerHolder;
    }

    /**
     * Sets the currently  active {@code UnityWallpaperService.UnityPlayerHolder}.
     * @param unityPlayerHolder Currently active {@code UnityWallpaperService.UnityPlayerHolder}.
     */
    public void setActiveUnityPlayerHolder(UnityPlayerHolder unityPlayerHolder) {
        mActiveUnityPlayerHolder = unityPlayerHolder;
    }

    /**
     * @return New {@code UnityPlayerHolder} instance.
     */
    public UnityPlayerHolder createUnityPlayerHolder() {
        return new UnityPlayerHolder(mUnityPlayerPauseResumeManager);
    }

    /**
     * Requests that Unity player should be created.
     * @param contextWrapper
     */
    public synchronized void requestCreateUnityPlayer(ContextWrapper contextWrapper) {
        // If provided context is actually an Activity, use that Activity when instantiating the Unity player
        if (contextWrapper instanceof Activity) {
            Activity activity = (Activity) contextWrapper;
            createUnityPlayerFromActivity(activity, false);
            return;
        }

        createUnityPlayerViaInstantiatorActivity(contextWrapper);
    }

    /**
     * Creates a {@code UnityPlayerWrapper} immediately using the {@code contextWrapper}.
     * @param contextWrapper {@code ContextWrapper} passed to {@code UnityPlayer} constructor.
     */
    public synchronized void createUnityPlayerDirectly(ContextWrapper contextWrapper) {
        if (mUnityPlayerWrapper != null)
            return;

        DebugLog.v("Instantiating Unity Player");
        mUnityPlayerWrapper = new UnityPlayerWrapper(contextWrapper);
        mUnityPlayerPauseResumeManager.setUnityPlayerWrapper(mUnityPlayerWrapper);
        notifyUnityPlayerInstanceCreatedListeners();
    }

    public synchronized void createUnityPlayerFromActivity(final Activity activity, final boolean finishActivityAfterCreation) {
        if (mUnityPlayerWrapper != null) {
            DebugLog.e("createUnityPlayerFromActivity called when mUnityPlayerWrapper != null");
            return;
        }

        Runnable instantiatePlayerRunnable = new Runnable() {
            @Override
            public void run() {
                // For some reason, Android creates a new permission request dialog each time Activity
                // is minimized and maximized again. This is weird, but safe to ignore.
                if (mUnityPlayerWrapper != null) {
                    DebugLog.d("Permission request dialog returned, but mUnityPlayerWrapper != null. " +
                            "This is weird. Perhaps the Activity was minimized when the permission request dialog " +
                            "was visible?");
                    return;
                }

                // Save current theme
                final int currentThemeResId = ActivityThemeUtility.getThemeResId(activity);
                ContextWrapper unityPlayerContext =
                        UnityVersionInfo.getInstance().isUnityNonActivityConstructorBugFixed() ?
                                activity.getApplication() :
                                activity;
                createUnityPlayerDirectly(unityPlayerContext);

                // For some reason, {@code UnityPlayer) resets the {@code Activity) theme, so we set it again.
                activity.setTheme(currentThemeResId);

                if (finishActivityAfterCreation) {
                    activity.finish();
                }
            }
        };

        PermissionsRequestUtility.requestPermissionDialog(activity, instantiatePlayerRunnable);
    }

    /**
     * Starts {@code UnityPlayerInstantiatorActivity}, which will then instantiate the {@code UnityPlayer}.
     * @param context {@code Context} used to start the {@code UnityPlayerInstantiatorActivity}
     * @see UnityPlayerInstantiatorActivity
     */
    private void createUnityPlayerViaInstantiatorActivity(Context context) {
        if (mUnityPlayerWrapper != null) {
            DebugLog.e("createUnityPlayerViaInstantiatorActivity called when mUnityPlayerWrapper != null");
            return;
        }

        Intent intent = new Intent(context, UnityPlayerInstantiatorActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    /**
     * Registers a {@code IUnityPlayerInstanceCreatedListener} to be called when {@code UnityPlayer} instance is created.
     * Note: there is no unregister method. Listener list is cleared automatically when
     * {@code UnityPlayer} instance is created.
     * @param listener
     */
    public synchronized void registerUnityPlayerInstanceCreatedListener(IUnityPlayerInstanceCreatedListener listener) {
        if (listener == null)
            throw new IllegalArgumentException("listener == null");

        mUnityPlayerInstanceCreatedListeners.add(listener);
        if (mUnityPlayerWrapper != null) {
            DebugLog.e("Adding IUnityPlayerInstanceCreatedListener when mUnityPlayerWrapper != null");
            notifyUnityPlayerInstanceCreatedListeners();
        }
    }

    /**
     * Notifies listeners that an {@code UnityPlayer} instance was created.
     */
    private void notifyUnityPlayerInstanceCreatedListeners() {
        DebugLog.v("Notifying UnityPlayerInstanceCreatedListeners");

        for (IUnityPlayerInstanceCreatedListener listener : mUnityPlayerInstanceCreatedListeners) {
            listener.onUnityPlayerInstanceCreated();
        }

        mUnityPlayerInstanceCreatedListeners.clear();
    }
}
