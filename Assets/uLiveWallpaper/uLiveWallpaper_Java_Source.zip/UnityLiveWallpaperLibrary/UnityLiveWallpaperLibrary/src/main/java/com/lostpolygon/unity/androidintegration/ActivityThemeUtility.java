/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;

import com.lostpolygon.unity.livewallpaper.R;

/**
 * Utilities for making Activities invisible.
 */
public final class ActivityThemeUtility {
    /**
     * Sets Activity theme to an invisible one.
     * @param activity
     */
    public static void setInvisibleTheme(final Activity activity, final boolean useNoDisplayTheme) {
        activity.setTheme(useNoDisplayTheme ? android.R.style.Theme_NoDisplay : R.style.uLiveWallpaper_Translucent);
    }

    /**
     * Returns theme resource id from an Activity.
     * @param activity
     * @return
     */
    public static int getThemeResId(final Activity activity) {
        ActivityInfo activityInfo;
        try {
            activityInfo = activity.getPackageManager().getActivityInfo(activity.getComponentName(), 0);
            int themeResId = activityInfo.theme;
            return themeResId;
        } catch (PackageManager.NameNotFoundException e) {
            return 0;
        }
    }
}
