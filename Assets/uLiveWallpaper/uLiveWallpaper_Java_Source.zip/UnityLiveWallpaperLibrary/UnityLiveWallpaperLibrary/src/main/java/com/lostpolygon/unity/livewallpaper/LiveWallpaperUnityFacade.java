/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.livewallpaper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.preference.PreferenceManager;

import com.lostpolygon.unity.androidintegration.MultiTapDetector;
import com.lostpolygon.unity.androidintegration.UnityPlayerInstanceManager;
import com.lostpolygon.unity.androidintegration.UnityPlayerWrapper;
import com.lostpolygon.unity.livewallpaper.activities.LiveWallpaperCompatibleUnityPlayerActivity;

/**
 * Central class for communicating with Unity C# side. All interactions to and from C# side are done here.
 */
public final class LiveWallpaperUnityFacade {
    /**
     * Singleton instance.
     */
    private static LiveWallpaperUnityFacade sInstance;
    private static final UnityEventsProxy sUnityEventsProxy = new UnityEventsProxy();

    private final Context mApplicationContext;
    private final PreferenceEditorFacade mPreferenceEditorFacade;
    private final WallpaperEngineFacade mWallpaperEngineFacade;
    private final MultiTapDetector mMultiTapDetector = new MultiTapDetector(new Point(0, 0));

    /**
     * Currently active {@code UnityWallpaperService.UnityWallpaperEngine}, or null if none is active.
     */
    private UnityWallpaperService.UnityWallpaperEngine mActiveWallpaperEngine;

    /**
     * Returns the singleton instance.
     * @return Instance of {@code LiveWallpaperUnityFacade}, or null if Unity player has not started yet.
     */
    public synchronized static LiveWallpaperUnityFacade getInstance() {
        if (sInstance == null) {
            final UnityPlayerWrapper unityPlayerWrapper = UnityPlayerInstanceManager.getInstance().getUnityPlayerWrapperInstance();
            if (unityPlayerWrapper == null)
                return null;

            Context applicationContext = unityPlayerWrapper.getApplicationContext();
            sInstance = new LiveWallpaperUnityFacade(applicationContext);
        }

        return sInstance;
    }

    /**
     * @param context Application Context.
     */
    private LiveWallpaperUnityFacade(Context context) {
        mApplicationContext = context;
        mPreferenceEditorFacade = new PreferenceEditorFacade();
        mWallpaperEngineFacade = new WallpaperEngineFacade();
    }

    /**
     * Note: Called from C# code.
     * @return Application {@code Context}.
     */
    public Context getApplicationContext() {
        return mApplicationContext;
    }

    /**
     * Note: Called from C# code.
     * @return Instance of {@code LiveWallpaperUnityFacade.PreferenceEditorFacade}.
     */
    public PreferenceEditorFacade getPreferencesEditorFacade() {
        return mPreferenceEditorFacade;
    }

    /**
     * Note: Called from C# code.
     * @return Instance of {@code UnityEventsProxy}.
     */
    public static UnityEventsProxy getEventsProxy() {
        return sUnityEventsProxy;
    }

    /**
     * Note: Called from C# code.
     * @return Instance of {@code LiveWallpaperUnityFacade.WallpaperEngineFacade}.
     */
    public WallpaperEngineFacade getWallpaperEngineFacade() {
        return mWallpaperEngineFacade;
    }

    /**
     * Note: Called from C# code.
     * @return Instance of {@code MultiTapDetector}.
     */
    public MultiTapDetector getMultiTapDetector() {
        return mMultiTapDetector;
    }

    /**
     * @return Currently active {@code UnityWallpaperService.UnityWallpaperEngine}, or null if none is active.
     */
    public UnityWallpaperService.UnityWallpaperEngine getActiveWallpaperEngine() {
        return mActiveWallpaperEngine;
    }

    /**
     * Sets the currently  active {@code UnityWallpaperService.UnityWallpaperEngine}.
     * @param activeWallpaperEngine Currently active {@code UnityWallpaperService.UnityWallpaperEngine}.
     */
    public void setActiveWallpaperEngine(UnityWallpaperService.UnityWallpaperEngine activeWallpaperEngine) {
        mActiveWallpaperEngine = activeWallpaperEngine;
    }

    /**
     * Updates the current Context of the {@code LiveWallpaperCompatibleUnityPlayerActivity}
     * to allow using soft input.
     * Note: Called from C# code.
     */
    public void updateUnityPlayerActivityContext() {
        LiveWallpaperCompatibleUnityPlayerActivity.updateUnityPlayerActivityContext();
    }

    /**
     * Provides safe access to current {@code WallpaperService.Engine} methods.
     */
    public class WallpaperEngineFacade {
        public boolean getIsVisible() {
            if (mActiveWallpaperEngine == null)
                return false;

            return mActiveWallpaperEngine.isVisible();
        }

        public boolean getIsPreview() {
            if (mActiveWallpaperEngine == null)
                return false;

            return mActiveWallpaperEngine.isPreview();
        }
    }

    /**
     * Provides safe access to {@code SharedPreferences} read/write operations.
     */
    public class PreferenceEditorFacade {
        private final SharedPreferences mDefaultSharedPreferences;
        private SharedPreferences.Editor mCurrentPreferencesEditor;

        public PreferenceEditorFacade() {
            mDefaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(mApplicationContext);
        }

        /**
         * Commit your preferences changes back from this Editor to the
         * {@link SharedPreferences} object it is editing.  This atomically
         * performs the requested modifications, replacing whatever is currently
         * in the SharedPreferences.
         */
        @SuppressLint("CommitPrefEdits")
        public boolean startEditing() {
            if (mCurrentPreferencesEditor != null)
                return false;

            mCurrentPreferencesEditor = mDefaultSharedPreferences.edit();
            return true;
        }

        /**
         * Commit your preferences changes back from this Editor to the
         * {@link SharedPreferences} object it is editing.  This atomically
         * performs the requested modifications, replacing whatever is currently
         * in the SharedPreferences.
         */
        public boolean finishEditing() {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.apply();
            mCurrentPreferencesEditor = null;
            return true;
        }

        /**
         * Checks whether the preferences contains a preference.
         *
         * @param key The name of the preference to check.

         * @return Returns true if the preference exists in the preferences, otherwise false.
         */
        public boolean hasKey(String key) {
            return mDefaultSharedPreferences.contains(key);
        }

        /**
         * Retrieve a String value from the preferences.
         *
         * @param key The name of the preference to retrieve.
         * @param defValue Value to return if this preference does not exist.
         *
         * @return Returns the preference value if it exists, or defValue.  Throws
         * ClassCastException if there is a preference with this name that is not
         * a String.
         *
         * @throws ClassCastException
         */
        public String getString(String key, String defValue) {
            return mDefaultSharedPreferences.getString(key, defValue);
        }

        /**
         * Retrieve a set of String values from the preferences.
         *
         * <p>Note that you <em>must not</em> modify the set instance returned
         * by this call.  The consistency of the stored data is not guaranteed
         * if you do, nor is your ability to modify the instance at all.
         *
         * @param key The name of the preference to retrieve.
         * @param defValues Values to return if this preference does not exist.
         *
         * @return Returns the preference values if they exist, or defValues.
         * Throws ClassCastException if there is a preference with this name
         * that is not a Set.
         *
         * @throws ClassCastException
         */
        //@Nullable
        //Set<String> getStringSet(String key, @Nullable Set<String> defValues);

        /**
         * Retrieve an int value from the preferences.
         *
         * @param key The name of the preference to retrieve.
         * @param defValue Value to return if this preference does not exist.
         *
         * @return Returns the preference value if it exists, or defValue.  Throws
         * ClassCastException if there is a preference with this name that is not
         * an int.
         *
         * @throws ClassCastException
         */
        public int getInt(String key, int defValue) {
            return mDefaultSharedPreferences.getInt(key, defValue);
        }

        /**
         * Retrieve a long value from the preferences.
         *
         * @param key The name of the preference to retrieve.
         * @param defValue Value to return if this preference does not exist.
         *
         * @return Returns the preference value if it exists, or defValue.  Throws
         * ClassCastException if there is a preference with this name that is not
         * a long.
         *
         * @throws ClassCastException
         */
        public long getLong(String key, long defValue) {
            return mDefaultSharedPreferences.getLong(key, defValue);
        }

        /**
         * Retrieve a float value from the preferences.
         *
         * @param key The name of the preference to retrieve.
         * @param defValue Value to return if this preference does not exist.
         *
         * @return Returns the preference value if it exists, or defValue.  Throws
         * ClassCastException if there is a preference with this name that is not
         * a float.
         *
         * @throws ClassCastException
         */
        public float getFloat(String key, float defValue) {
            return mDefaultSharedPreferences.getFloat(key, defValue);
        }

        /**
         * Retrieve a boolean value from the preferences.
         *
         * @param key The name of the preference to retrieve.
         * @param defValue Value to return if this preference does not exist.
         *
         * @return Returns the preference value if it exists, or defValue.  Throws
         * ClassCastException if there is a preference with this name that is not
         * a boolean.
         *
         * @throws ClassCastException
         */
        public boolean getBoolean(String key, boolean defValue) {
            return mDefaultSharedPreferences.getBoolean(key, defValue);
        }

        /**
         * Set a String value in the preferences.
         *
         * @param key The name of the preference to modify.
         * @param value The new value for the preference.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean putString(String key, String value) {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.putString(key, value);
            return true;
        }

        /**
         * Set a set of String values in the preferences.
         *
         * @param key The name of the preference to modify.
         * @param values The set of new values for the preference.  Passing {@code null}
         *    for this argument is equivalent to calling {@link #remove(String)} with
         *    this key.
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        //Editor putStringSet(String key, @Nullable Set<String> values);

        /**
         * Set an int value in the preferences.
         *
         * @param key The name of the preference to modify.
         * @param value The new value for the preference.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean putInt(String key, int value) {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.putInt(key, value);
            return true;
        }

        /**
         * Set a long value in the preferences
         *
         * @param key The name of the preference to modify.
         * @param value The new value for the preference.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean putLong(String key, long value) {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.putLong(key, value);
            return true;
        }

        /**
         * Set a float value in the preferences.
         *
         * @param key The name of the preference to modify.
         * @param value The new value for the preference.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean putFloat(String key, float value) {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.putFloat(key, value);
            return true;
        }

        /**
         * Set a boolean value in the preferences.
         *
         * @param key The name of the preference to modify.
         * @param value The new value for the preference.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean putBoolean(String key, boolean value) {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.putBoolean(key, value);
            return true;
        }

        /**
         * Remove value from the preferences.
         *
         * @param key The name of the preference to remove.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean remove(String key) {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.remove(key);
            return true;
        }

        /**
         * Remove all values from the preferences.
         *
         * @return true if editing has started and operation succeeded, false otherwise.
         */
        public boolean clear() {
            if (mCurrentPreferencesEditor == null)
                return false;

            mCurrentPreferencesEditor.clear();
            return true;
        }
    }
}
