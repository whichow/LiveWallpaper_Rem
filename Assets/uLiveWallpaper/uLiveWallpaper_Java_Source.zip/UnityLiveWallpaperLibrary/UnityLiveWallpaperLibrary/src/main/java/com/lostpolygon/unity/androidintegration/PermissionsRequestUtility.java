/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.os.Build;

/**
 * Utility methods for working with Android 6.0 new permission model.
 */
public final class PermissionsRequestUtility {
    private PermissionsRequestUtility() { }

    private static boolean isSkipPermissionsDialog(final PackageItemInfo packageItemInfo) {
        try {
            return packageItemInfo.metaData.getBoolean("uLiveWallpaper.SkipPermissionsDialog");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Shows a permission request dialog, if needed, and runs the {@code Runnable} when ready.
     * @param activity Host Activity in which the permission request dialog is spawned.
     * @param runnable
     */
    @TargetApi(Build.VERSION_CODES.M)
    @SuppressLint("ValidFragment")
    public static void requestPermissionDialog(final Activity activity, final Runnable runnable) {
        if (activity == null)
            throw new IllegalArgumentException("activity == null");

        final PackageManager packageManager = activity.getPackageManager();
        final ApplicationInfo applicationInfo;
        try {
            applicationInfo = packageManager.getApplicationInfo(activity.getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            DebugLog.e("PermissionsRequestUtility: Unable to retrieve ApplicationInfo. This should not ever happen.");
            runRunnable(runnable);
            return;
        }

        if (applicationInfo.targetSdkVersion < Build.VERSION_CODES.M || Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            DebugLog.v("PermissionsRequestUtility: API < 23, starting runnable directly");
            runRunnable(runnable);
            return;
        }

        if (isSkipPermissionsDialog(applicationInfo)) {
            DebugLog.d("PermissionsRequestUtility: permission request dialog skipped");
            runRunnable(runnable);
            return;
        }

        try {
            final PackageInfo packageInfo = packageManager.getPackageInfo(activity.getPackageName(), PackageManager.GET_PERMISSIONS);
            if (packageInfo.requestedPermissions == null) {
                packageInfo.requestedPermissions = new String[0];
            }

            final List<String> dangerousPermissions = new ArrayList<>();
            String[] requestedPermissions = packageInfo.requestedPermissions;
            for (final String requestedPermission : requestedPermissions) {
                try {
                    if (packageManager.getPermissionInfo(requestedPermission, PackageManager.GET_META_DATA).protectionLevel == PermissionInfo.PROTECTION_DANGEROUS) {
                        if (activity.checkCallingOrSelfPermission(requestedPermission) != PackageManager.PERMISSION_GRANTED) {
                            dangerousPermissions.add(requestedPermission);
                        }
                    }
                } catch (PackageManager.NameNotFoundException e) {
                    DebugLog.e("Failed to get permission info for " + requestedPermission + ", manifest likely missing custom permission declaration");
                    DebugLog.e("Permission " + requestedPermission + " ignored");
                }
            }

            if (dangerousPermissions.isEmpty()) {
                DebugLog.v("PermissionsRequestUtility: no dangerous non-granted permissions found, starting runnable");
                runRunnable(runnable);
                return;
            }

            DebugLog.d("Detected " + dangerousPermissions.size() + " dangerous permissions that will be requested");

            final FragmentManager fragmentManager = activity.getFragmentManager();
            final FragmentTransaction tempFragmentAddTransaction = fragmentManager.beginTransaction();
            tempFragmentAddTransaction.add(0, new Fragment() {
                private static final int PERMISSION_REQUEST_CODE = 37378;

                public final void onStart() {
                    super.onStart();

                    requestPermissions(dangerousPermissions.toArray(new String[dangerousPermissions.size()]), PERMISSION_REQUEST_CODE);
                }

                public final void onRequestPermissionsResult(int requestCode, final String[] permissions, final int[] grantResults) {
                    if (requestCode != PERMISSION_REQUEST_CODE)
                        return;

                    if (grantResults.length > 0) {
                        String permissionsGrantedLogMessage = "PermissionsRequestUtility: Permission request result:\n";
                        for (int i = 0; i < permissions.length && i < grantResults.length; i++) {
                            permissionsGrantedLogMessage += permissions[i] + ((grantResults[i] == PackageManager.PERMISSION_GRANTED) ? " granted" : " denied") + "\n";
                        }

                        DebugLog.d(permissionsGrantedLogMessage);
                    }

                    final FragmentTransaction tempFragmentRemoveTransaction = fragmentManager.beginTransaction();
                    tempFragmentRemoveTransaction.remove(this);
                    tempFragmentRemoveTransaction.commit();

                    DebugLog.d("PermissionsRequestUtility: permission request complete, starting runnable");
                    runRunnable(runnable);
                }
            });
            tempFragmentAddTransaction.commit();
        } catch (Exception e) {
            DebugLog.e("Unable to query for permission.");
            e.printStackTrace();
        }
    }

    private static void runRunnable(Runnable runnable) {
        try {
            runnable.run();
        } catch (Throwable tr) {
            tr.printStackTrace();
        }
    }
}
