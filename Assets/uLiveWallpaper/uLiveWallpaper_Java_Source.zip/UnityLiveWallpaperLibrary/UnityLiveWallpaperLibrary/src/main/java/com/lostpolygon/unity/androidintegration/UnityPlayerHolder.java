package com.lostpolygon.unity.androidintegration;

import android.view.SurfaceHolder;

/**
 * An object that holds a lock on Unity player. Unity player's main loop is only active when at least
 * one {@code UnityPlayerHolder} is visible.
 */
public class UnityPlayerHolder {
    private final UnityPlayerPauseResumeManager mUnityPlayerPauseResumeManager;
    private boolean mIsVisible;

    public UnityPlayerHolder(UnityPlayerPauseResumeManager unityPlayerPauseResumeManager) {
        mUnityPlayerPauseResumeManager = unityPlayerPauseResumeManager;
    }

    public boolean isVisible() {
        return mIsVisible;
    }

    public boolean onVisibilityChanged(boolean isVisible, SurfaceHolder newSurfaceHolder) {
        mIsVisible = isVisible;
        return mUnityPlayerPauseResumeManager.handleUnityPlayerHolderVisibilityChanged(this, newSurfaceHolder);
    }

    public void unregister() {
        onVisibilityChanged(false, null);
        mUnityPlayerPauseResumeManager.unregisterUnityPlayerHolder(this);
    }
}
