/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.livewallpaper;

/**
 * Describes all events that are sent from Java side to Unity.
 */
public interface ILiveWallpaperEventsListener {
    /**
     * Called to inform whether the wallpaper has become visible or not visible.
     * @param isVisible
     */
    void visibilityChanged(boolean isVisible);

    /**
     * Called to inform whether the wallpaper has entered or exited the preview mode.
     * @param isPreview
     */
    void isPreviewChanged(boolean isPreview);

    /**
     * Called to inform about the change of wallpaper desired size.
     * @param desiredWidth
     * @param desiredHeight
     */
    void desiredSizeChanged(int desiredWidth, int desiredHeight);

    /**
     * Called to inform about change of wallpaper offsets.
     * @param xOffset
     * @param yOffset
     * @param xOffsetStep
     * @param yOffsetStep
     * @param xPixelOffset
     * @param yPixelOffset
     */
    void offsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset);

    /**
     * Called to inform about the change of preference value.
     * @param key SharedPreferences preference key that has changed.
     */
    void preferenceChanged(String key);

    /**
     * Called to inform that live wallpaper preferences Activity has started.
     */
    void preferencesActivityTriggered();

    /**
     * Called to inform about a custom event.
     * @param eventName Name of the event.
     * @param eventData Event data.
     */
    void customEventReceived(String eventName, String eventData);

    /**
     * Called to inform that user has tapped the screen multiple times.
     */
    void multiTapDetected(float finalTapPositionX, float finalTapPositionY);
}
