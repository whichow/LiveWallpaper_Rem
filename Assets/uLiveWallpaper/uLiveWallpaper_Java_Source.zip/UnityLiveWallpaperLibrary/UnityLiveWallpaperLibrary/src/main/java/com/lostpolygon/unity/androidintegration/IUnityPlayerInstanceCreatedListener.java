/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

/**
 * Listens for when {@code com.unity3d.player.UnityPlayer} instance is created.
 */
public interface IUnityPlayerInstanceCreatedListener {
    void onUnityPlayerInstanceCreated();
}
