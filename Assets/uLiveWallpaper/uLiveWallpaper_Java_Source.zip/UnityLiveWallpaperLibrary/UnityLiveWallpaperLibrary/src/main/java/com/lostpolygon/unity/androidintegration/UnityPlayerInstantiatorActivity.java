/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import android.app.Activity;
import android.os.Bundle;

/**
 * An invisible {@code Activity} that provides a {@code Context} for {@code UnityPlayer} construction.
 *
 * For some reason, current Unity versions crash if {@code new UnityPlayer(context)} argument
 * is anything other than an {@code Activity} ({@code WallpaperService}, for example). So we create an
 * {@code Activity}, use it to instantiate {@code UnityPlayer}, and immediately kill the {@code Activity}.
 */
public final class UnityPlayerInstantiatorActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Update Unity version info
        UnityVersionInfo.updateUnityVersionIfNeeded(this);

        // Just close the Activity if there is nothing to do
        if (UnityPlayerInstanceManager.getInstance().getUnityPlayerWrapperInstance() != null) {
            DebugLog.e(
                    "UnityPlayerInstantiatorActivity created when " +
                    "UnityPlayer is already created. This should not happen.");
            finish();
            return;
        }

        // Create the {@code UnityPlayer)
        UnityPlayerInstanceManager.getInstance().createUnityPlayerFromActivity(this, true);
    }
}
