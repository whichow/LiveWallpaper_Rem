/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.livewallpaper;

import android.annotation.TargetApi;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;

import com.lostpolygon.unity.androidintegration.DebugLog;

/**
 * Various useful live wallpaper related methods.
 */
public final class LiveWallpaperUtility {
    private LiveWallpaperUtility() { }

    /**
     * Opens the wallpaper preview screen, if possible.
     * @param context
     * @param newTask Whether to set the {@code Intent.FLAG_ACTIVITY_NEW_TASK} flag when constructing
     *                the {@code Intent}. Should be set to true when called not from within an Activity.
     * @return true on success, false on error.
     */
    public static boolean openWallpaperPreview(final Context context, final boolean newTask) {
        ComponentName componentName = getWallpaperServiceComponentName(context);
        if (componentName == null) {
            DebugLog.e("No wallpaper service found");
            return false;
        }

        DebugLog.d("Starting live wallpaper preview screen for " + componentName.getClassName());
        return openWallpaperPreview(context, componentName, newTask);
    }

    /**
     * Opens the wallpaper preview screen, if possible.
     * @param context
     * @param componentName The live wallpaper service component name.
     * @param newTask Whether to set the {@code Intent.FLAG_ACTIVITY_NEW_TASK} flag when constructing
     *                the {@code Intent}. Should be set to true when called not from within an Activity.
     * @return true on success, false on error.
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static boolean openWallpaperPreview(final Context context, ComponentName componentName, final boolean newTask) {
        Intent intent;

        try {
            // Jelly Bean allows to open preview of exact wallpaper
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, componentName);
                if (newTask) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                context.startActivity(intent);

                return true;
            }
        } catch (ActivityNotFoundException ignored) {
            DebugLog.d("Unable to open live wallpaper preview using Jelly Bean method, using fallback");
            /*
            Happens at least on Samsung Galaxy S7:
            java.lang.RuntimeException: Unable to start activity ComponentInfo{...}: android.content.ActivityNotFoundException: No Activity found to handle Intent
            { act=android.service.wallpaper.CHANGE_LIVE_WALLPAPER ...
             */
        }

        try {
            // Generic Android wallpaper chooser
            intent = new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);
            if (newTask) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(intent);

            return true;
        } catch (ActivityNotFoundException ignored) {
            DebugLog.d("Unable to open wallpaper preview using generic live wallpaper chooser, using fallback");
        }

        return false;
    }

    /**
     * Searches for the first live wallpaper service and returns its {@code ServiceInfo}.
     * @param context
     * @return {@code ServiceInfo} of wallpaper service on success, null on error.
     */
    public static ServiceInfo getWallpaperServiceInfo(final Context context) {
        try {
            final PackageInfo packageInfo =
                    context
                            .getPackageManager()
                            .getPackageInfo(
                                    context.getPackageName(),
                                    PackageManager.GET_SERVICES | PackageManager.GET_META_DATA | PackageManager.GET_INTENT_FILTERS
                            );
            final ServiceInfo[] services = packageInfo.services;
            for (ServiceInfo service : services) {
                if (service.metaData != null && service.metaData.containsKey("android.service.wallpaper"))
                    return service;
            }
        } catch (PackageManager.NameNotFoundException ignored) {
        }

        return null;
    }

    private static ComponentName getWallpaperServiceComponentName(final Context context) {
        final ServiceInfo wallpaperService = getWallpaperServiceInfo(context);
        if (wallpaperService == null)
            return null;

        return new ComponentName(wallpaperService.packageName, wallpaperService.name);
    }
}
