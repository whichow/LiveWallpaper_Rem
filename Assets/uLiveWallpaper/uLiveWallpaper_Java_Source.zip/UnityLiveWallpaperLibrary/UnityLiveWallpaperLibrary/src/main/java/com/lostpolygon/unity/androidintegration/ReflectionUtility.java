/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;

import android.content.Context;

import dalvik.system.DexFile;
import dalvik.system.PathClassLoader;

/**
 * Collection of Reflection-related utility methods.
 */
final class ReflectionUtility {
    private static Field sPathClassLoaderDexField;
    private static Field sBaseDexClassLoaderPathListField;
    private static Field sDexPathListDexElementsField;
    private static Field sDexPathListElementDexFileField;

    private ReflectionUtility() { }

    static {
        try {
            sPathClassLoaderDexField = PathClassLoader.class.getDeclaredField("mDexs");
            sPathClassLoaderDexField.setAccessible(true);
        } catch (NoSuchFieldException ignored) {
        }

        try {
            sBaseDexClassLoaderPathListField = PathClassLoader.class.getSuperclass().getDeclaredField("pathList");
            sBaseDexClassLoaderPathListField.setAccessible(true);

            Class sDexPathListClass = sBaseDexClassLoaderPathListField.getType();
            sDexPathListDexElementsField = sDexPathListClass.getDeclaredField("dexElements");
            sDexPathListDexElementsField.setAccessible(true);
            Class sDexPathListElementClass = sDexPathListDexElementsField.getType().getComponentType();
            sDexPathListElementDexFileField = sDexPathListElementClass.getDeclaredField("dexFile");
            sDexPathListElementDexFileField.setAccessible(true);
        } catch (NoSuchFieldException ignored) {
        }
    }

    private static HashSet<DexFile> getDexFiles() {
        HashSet<DexFile> dexFiles = new HashSet<>();

        PathClassLoader classLoader = (PathClassLoader) Thread.currentThread().getContextClassLoader();
        if (sPathClassLoaderDexField != null) {
            try {
                DexFile[] pathClassLoaderDexs = (DexFile[]) sPathClassLoaderDexField.get(classLoader);
                dexFiles.addAll(Arrays.asList(pathClassLoaderDexs));
            } catch (IllegalAccessException ignored) {
            }
        }

        if (sDexPathListElementDexFileField != null) {
            try {
                final Object dexClassLoaderPathList = sBaseDexClassLoaderPathListField.get(classLoader);
                final Object elementsArray = sDexPathListDexElementsField.get(dexClassLoaderPathList);
                int elementsArrayLength = Array.getLength(elementsArray);
                for (int i = 0; i < elementsArrayLength; i++) {
                    Object elementsArrayElement = Array.get(elementsArray, i);
                    final DexFile dexFile = (DexFile) sDexPathListElementDexFileField.get(elementsArrayElement);
                    dexFiles.add(dexFile);
                }
            } catch (IllegalAccessException ignored) {
            }
        }

        return dexFiles;
    }

    /** Returns classes inside the {@code packageName} package.
     * @param context Application context.
     * @param packageName Name of the package.
     * @return Classes inside the {@code packageName} package.
     */
    public static Class[] getClassesOfPackage(Context context, String packageName) {
        final HashSet<DexFile> dexFiles = getDexFiles();

        try {
            String packageCodePath = context.getPackageCodePath();
            DexFile df = new DexFile(packageCodePath);

            dexFiles.add(df);
        } catch (IOException e) {
            e.printStackTrace();
        }

        HashSet<Class> classes = new HashSet<>();
        for (DexFile df : dexFiles) {
            for (Enumeration<String> iterator = df.entries(); iterator.hasMoreElements(); ) {
                String className = iterator.nextElement();
                if (className.startsWith(packageName)) {
                    try {
                        classes.add(Class.forName(className));
                    } catch (ClassNotFoundException e) {
                        // Ignored
                    }
                }
            }
        }

        return classes.toArray(new Class[classes.size()]);
    }
}
