/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.livewallpaper.activities;

import android.app.Activity;
import android.os.Bundle;

import com.lostpolygon.unity.livewallpaper.LiveWallpaperUtility;

/**
 * An invisible Activity that opens the wallpaper preview app for current wallpaper,
 * and then closes itself.
 */
public class StartWallpaperPreviewActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LiveWallpaperUtility.openWallpaperPreview(this, false);
        finish();
    }
}
