/*
 * Copyright (c) 2016, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.androidintegration;

import java.util.LinkedList;
import java.util.List;

import android.graphics.Point;
import android.os.SystemClock;
import android.view.MotionEvent;

/**
 * Detects quick sequences of touch taps and notifies listeners about them.
 */
public class MultiTapDetector {
    private final List<IMultiTapDetectedListener> mMultiTapDetectedListeners = new LinkedList<>();
    private Point mScreenSize = new Point();
    private int mNumberOfTaps = 3;
    private long mMaxTimeBetweenTaps = 250;
    private float mTapZoneRadiusRelative = 0.15f;
    private float mTapZoneRadiusAbsolute;

    private long mLastTapTime;
    private float mLastTapPositionX;
    private float mLastTapPositionY;
    private int mCurrentTapCount;

    public MultiTapDetector(Point screenSize) {
        setScreenSize(screenSize);
    }

    /**
     * Processes the touch event.
     */
    public void onTouchEvent(final MotionEvent motionEvent) {
        // We are only interested in the tap event
        if (motionEvent.getAction() != MotionEvent.ACTION_DOWN)
            return;

        long currentTime = SystemClock.uptimeMillis();
        long timeDeltaBetweenTaps = currentTime - mLastTapTime;
        float tapPositionX = motionEvent.getX();
        float tapPositionY = motionEvent.getY();

        if (mCurrentTapCount > 0) {
            // Reset if taps are too far apart in time or position
            if (timeDeltaBetweenTaps > mMaxTimeBetweenTaps) {
                mCurrentTapCount = 0;
            } else {
                float distanceToLastTapPosition = distanceBetweenPoints(mLastTapPositionX, mLastTapPositionY, tapPositionX, tapPositionY);
                if (distanceToLastTapPosition > mTapZoneRadiusAbsolute) {
                    mCurrentTapCount = 0;
                }
            }
        }

        mLastTapTime = currentTime;
        mLastTapPositionX = tapPositionX;
        mLastTapPositionY = tapPositionY;
        mCurrentTapCount++;

        if (mCurrentTapCount >= mNumberOfTaps) {
            mCurrentTapCount = 0;
            notifyListeners();

            DebugLog.v("MultiTapDetector.notifyListeners();");
        }
    }

    /**
     * Gets the screen size, used for calculating relative distance between taps.
     * @return Screen size.
     */
    public Point getScreenSize() {
        return mScreenSize;
    }

    /**
     * Sets the screen size, used for calculating relative distance between taps.
     * @param screenSize
     */
    public void setScreenSize(Point screenSize) {
        mScreenSize = screenSize;
        updateTapRadius();
    }

    /**
     * @return Number of consequent taps required to register an event.
     */
    public int getNumberOfTaps() {
        return mNumberOfTaps;
    }

    /**
     * @param numberOfTaps Number of consequent taps required to register an event.
     */
    public void setNumberOfTaps(int numberOfTaps) {
        if (numberOfTaps < 1)
            throw new IllegalArgumentException("numberOfTaps must be >= 1");

        mNumberOfTaps = numberOfTaps;
    }

    /**
     * @return Maximum time between taps to count them as one sequence.
     */
    public long getMaxTimeBetweenTaps() {
        return mMaxTimeBetweenTaps;
    }

    /**
     * @param maxTimeBetweenTaps Maximum time between taps to count them as one sequence.
     */
    public void setMaxTimeBetweenTaps(long maxTimeBetweenTaps) {
        if (maxTimeBetweenTaps <= 0)
            throw new IllegalArgumentException("maxTimeBetweenTaps must be positive");

        mMaxTimeBetweenTaps = maxTimeBetweenTaps;
    }

    /**
     * @return Relative maximum distance between sequential taps.
     * For example, value of 0.5 allows sequential taps to be half a screen away from each other.
     */
    public float getTapZoneRadiusRelative() {
        return mTapZoneRadiusRelative;
    }

    /**
     * @param tapZoneRadiusRelative Relative maximum distance between sequential taps.
     * For example, value of 0.5 allows sequential taps to be half a screen away from each other.
     */
    public void setTapZoneRadiusRelative(float tapZoneRadiusRelative) {
        if (tapZoneRadiusRelative <= 0)
            throw new IllegalArgumentException("tapZoneRadiusRelative must be positive");

        if (tapZoneRadiusRelative > 1f || tapZoneRadiusRelative < 0.01f)
            throw new IllegalArgumentException("tapZoneRadiusRelative must be in range [0.01, 1]");

        mTapZoneRadiusRelative = tapZoneRadiusRelative;
        updateTapRadius();
    }

    /**
     * Registers the multi tap event listener.
     * @param listener
     */
    public synchronized void registerMultiTapDetectedListener(IMultiTapDetectedListener listener) {
        if (listener == null)
            throw new IllegalArgumentException("listener == null");

        mMultiTapDetectedListeners.add(listener);
    }

    /**
     * Unregisters the multi tap event listener.
     * @param listener
     */
    public synchronized void unregisterMultiTapDetectedListener(IMultiTapDetectedListener listener) {
        if (listener == null)
            throw new IllegalArgumentException("listener == null");

        mMultiTapDetectedListeners.remove(listener);
    }

    private void updateTapRadius() {
        mTapZoneRadiusAbsolute = (mScreenSize.x + mScreenSize.y) * 0.5f * mTapZoneRadiusRelative;
    }

    private void notifyListeners() {
        for (IMultiTapDetectedListener listener : mMultiTapDetectedListeners) {
            listener.onMultiTapDetected(mLastTapPositionX, mLastTapPositionY);
        }
    }

    private static float distanceBetweenPoints(float point1x, float point1y, float point2x, float point2y) {
        double xDiff = point1x - point2x;
        double yDiff = point1y - point2y;
        return (float) Math.sqrt(xDiff * xDiff + yDiff * yDiff);
    }

    /**
     * Multi tap event listener.
     */
    public interface IMultiTapDetectedListener {
        void onMultiTapDetected(float finalTapPositionX, float finalTapPositionY);
    }
}
