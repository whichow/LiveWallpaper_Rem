uLiveWallpaper Java Side Source Code
====================================

Thank you for buying uLiveWallpaper Pro!

This is the library Android Studio project for uLiveWallpaper Android plugin. It should build cleanly
as-is. Project uses target API 24. "unity-classes" module contains Unity player classes from Unity 5.1.3.

The build artifact is located at:
"UnityLiveWallpaperLibrary\UnityLiveWallpaperLibrary\build\outputs\aar\LP_uLiveWallpaper.aar".

Feel free to contact if you have any issues or questions:

E-mail: contact@lostpolygon.com
Skype: serhii.yolkin